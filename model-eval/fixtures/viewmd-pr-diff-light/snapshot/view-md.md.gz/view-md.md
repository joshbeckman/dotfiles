# Pull Request #304: [fix(git): pr-view prefers the gh view-md extension](https://github.com/joshbeckman/dotfiles/pull/304) opened by @joshbeckman on Thursday (2026-11-12) at 06:18:10

Josh asked for the extension, and `bin/git-pr-view` should use it.

`joshbeckman/gh-view-md` renders an issue or PR as full markdown for an LLM to read, which is what
`pr-view` is for. PR 302 had replaced the broken `gw view-md` call with `gh pr view`; that works but
reads less. Now that the extension is installed:

```sh
if gh extension list 2>/dev/null | grep -q '^gh view-md'; then
  exec gh view-md "$url"
fi
exec gh pr view "$url"
```

The extension is the good path. The fallback stays, so a machine without it still reads PRs rather
than failing, which is what happened before PR 302.

`test/pr-lookup` now fakes `gh` for both: `extension list` reporting the extension and `view-md`
answering, then a second PATH with no extension exercising the `gh pr view` fallback.
`bash test/pr-lookup` passes and `git pr-view 300` renders PR 300 as markdown here.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76C4XZFZYKMRZVFNE4J4Z9D


## Stats: 25 lines added, 5 lines deleted, 2 files changed

```diff
diff --git a/bin/git-pr-lookup b/bin/git-pr-lookup
index ef863cd1b..38af8bb6d 100755
--- a/bin/git-pr-lookup
+++ b/bin/git-pr-lookup
@@ -51,9 +51,12 @@ if [[ "$provider" == github ]]; then
     url) exec gw pr-url ${selector:+"$selector"} ;;
     view)
       url="$(gw pr-url ${selector:+"$selector"})" || die 'could not resolve the GitHub pull request'
-      # `gw` is a `gh` wrapper here and has no markdown viewer, so read the PR with `gh`
-      # itself. No `--comments`: on gh 2.103.3 it prints nothing and exits 0. Ask for
-      # comments separately with `gh pr view <url> --json comments`.
+      # Full markdown for an agent to read, when the `gh view-md` extension is installed.
+      # Otherwise `gh pr view`, which needs no extension. No `--comments` either way: on gh
+      # 2.103.3 it prints nothing and exits 0.
+      if gh extension list 2>/dev/null | grep -q '^gh view-md'; then
+        exec gh view-md "$url"
+      fi
       exec gh pr view "$url"
       ;;
     checks)
diff --git a/test/pr-lookup b/test/pr-lookup
index 4d3a46029..9d32b2694 100755
--- a/test/pr-lookup
+++ b/test/pr-lookup
@@ -23,8 +23,11 @@ chmod +x "$tmp/bin/gw"
 # `git pr-view` renders a GitHub PR with `gh` itself; `gw` has no markdown viewer.
 cat >"$tmp/bin/gh" <<'EOF2'
 #!/bin/sh
-[ "$1" = pr ] && [ "$2" = view ] || exit 2
-printf '# Full GitHub PR\n'
+case "$1" in
+  extension) [ "$2" = list ] && printf 'gh view-md\tjoshbeckman/gh-view-md\t1\n' ;;
+  view-md) printf '# Full GitHub PR\n' ;;
+  *) exit 2 ;;
+esac
 EOF2
 chmod +x "$tmp/bin/gh"
 
@@ -55,6 +58,20 @@ for operation in pr-url pr-view pr-merged pr-checks; do
 done
 [[ "$(run pr-url https://github.com/example/project/pull/7)" == 'https://github.com/example/project/pull/7' ]]
 [[ "$(run pr-view https://github.com/example/project/pull/7)" == '# Full GitHub PR' ]]
+# Without the `gh view-md` extension, `pr-view` falls back to `gh pr view`.
+casebin="$tmp/gh-no-ext"
+mkdir "$casebin"
+cat >"$casebin/gh" <<'EOF3'
+#!/bin/sh
+case "$1" in
+  extension) exit 0 ;;
+  pr) [ "$2" = view ] && printf '# Plain GitHub PR\n' ;;
+  *) exit 2 ;;
+esac
+EOF3
+chmod +x "$casebin/gh"
+out="$(cd "$tmp/repo" && PATH="$casebin:$tmp/bin:$root/bin:$PATH" git pr-view https://github.com/example/project/pull/7)"
+[[ "$out" == '# Plain GitHub PR' ]] || { printf 'pr-view fell back to: %s\n' "$out" >&2; exit 1; }
 [[ "$(run pr-merged https://github.com/example/project/pull/7)" == '2026-01-02T03:04:05Z' ]]
 expect_line '| Check | Status | Result |' pr-checks https://github.com/example/project/pull/7 --required
 

```

## @joshbeckman committed a change on Thursday (2026-11-12) at 06:18:02

fix(git): pr-view prefers the gh view-md extension

The extension renders a full PR as markdown, which is what an agent wants to read.
It is installed now, so delegate to it, and keep `gh pr view` as the fallback for a
machine without it. The lookup test covers both paths.

### ✅ @joshbeckman merged this on Thursday (2026-11-12) at 06:23:52

### 🔒 @joshbeckman closed this on Thursday (2026-11-12) at 06:23:52



## Merged on Thursday (2026-11-12) at 06:23:52
