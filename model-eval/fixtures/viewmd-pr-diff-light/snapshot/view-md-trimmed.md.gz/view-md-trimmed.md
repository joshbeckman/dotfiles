# Pull Request #304: [fix(git): pr-view prefers the gh view-md extension](https://github.com/joshbeckman/dotfiles/pull/304) opened by @joshbeckman on Thursday (2026-11-12) at 06:18:10

Josh asked for the extension, and `bin/git-pr-view` should use it.

`joshbeckman/gh-view-md` renders an issue or PR as full markdown for an LLM to read, which is what
`pr-view` is for. PR 302 had replaced the broken `gw view-md` call with `gh pr view`; that works but
reads less. Now that the extension is installed:

```sh
if gh extension list 2>/dev/null | grep -q '^gh view-md'; then
  exec gh view-md "$url"
fi
exec gh pr view "$url"
```

The extension is the good path. The fallback stays, so a machine without it still reads PRs rather
than failing, which is what happened before PR 302.

`test/pr-lookup` now fakes `gh` for both: `extension list` reporting the extension and `view-md`
answering, then a second PATH with no extension exercising the `gh pr view` fallback.
`bash test/pr-lookup` passes and `git pr-view 300` renders PR 300 as markdown here.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76C4XZFZYKMRZVFNE4J4Z9D


## Stats: 25 lines added, 5 lines deleted, 2 files changed

```text
bin/git-pr-lookup
test/pr-lookup

```

## @joshbeckman committed a change on Thursday (2026-11-12) at 06:18:02

fix(git): pr-view prefers the gh view-md extension

The extension renders a full PR as markdown, which is what an agent wants to read.
It is installed now, so delegate to it, and keep `gh pr view` as the fallback for a
machine without it. The lookup test covers both paths.

### ✅ @joshbeckman merged this on Thursday (2026-11-12) at 06:23:52

### 🔒 @joshbeckman closed this on Thursday (2026-11-12) at 06:23:52



## Merged on Thursday (2026-11-12) at 06:23:52
