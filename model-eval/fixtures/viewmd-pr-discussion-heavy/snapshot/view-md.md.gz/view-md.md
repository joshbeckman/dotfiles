# Pull Request #294: [feat(pana): set s secrets from the settings page](https://github.com/joshbeckman/dotfiles/pull/294) opened by @joshbeckman on Thursday (2026-11-12) at 03:20:20

The pana Settings page now lists the names in your `s` store and sets, replaces, or removes one. A phone can store a credential without a terminal.

A session still reads a secret the ordinary way, `s NAME -- command`. pana holds nothing: the page sends `{name, value}`, and the daemon passes it to `s set -f NAME --stdin`, so a value never enters argv and never shows in `ps`. pana never reads one back (the real `s get` refuses without a TTY anyway). `GET /secrets` answers names only, and every response is `no-store`.

## What changed

- `src/secrets/`: the `s`-backed store. Calls serialise, because `s` rewrites its whole store on each write. A 15s hung `s` is killed rather than holding a request open.
- Routes `GET /secrets`, `POST /secrets`, `DELETE /secrets/:name`, all user-only and **TCP only** (SET-05 in `SPEC.md`). On the Unix socket an unlabeled caller is the user, so a session's bash holds that authority without naming itself; the token is required instead.
- Names are env-style and values are 1 byte to 64 KiB, no NUL, with trailing newlines dropped as `s` drops them: refused with 400 before `s` runs, and `s`'s own denylist of env names is 400 too. A name `s` does not hold is 404. A store panad cannot list reads as `available: false`; a write that cannot decrypt answers 502 with `s`'s own reason.
- Settings page: a **Secrets** panel with the name list, a name field, a masked value field with no control that reveals it, a per-row remove that asks inside that row, and a value field that empties on save and on leaving the page. The value is never displayed, so nothing in pana can show it back.
- The test harness defaults to an in-memory store, so no test reads the developer's real `s`.

![the secrets panel at desktop width](/tmp/gh_issue/github.com/joshbeckman/dotfiles/pull/294/github_image_1.png)

![the panel at phone width](/tmp/gh_issue/github.com/joshbeckman/dotfiles/pull/294/github_image_2.png)

## Tests

- `npx tsc --noEmit` clean; `npm test` 66 files, 798 tests pass.
- `test/secrets.test.ts` (8 tests): round trip through a stand-in `s` that records argv (the value is not in it), replace in place, 404 on a second remove, sessions refused on all three routes, every invalid name and value refused before `s` runs, a missing `s` reading as unavailable, a hung `s` killed at the timeout, and a final one against the real `s` binary on a throwaway `S_FILE`.
- `test/browser/settings.spec.ts`: sets a secret through the real form and route, and checks the field is masked, that no control can reveal it, that Clear empties it, that leaving the page drops a typed draft, that the saved value appears nowhere in the page, and that a bad name is refused before the confirm-guarded remove.
- `test/secrets.test.ts` also covers the review's findings: the first-line `s` error, `s`'s own name denylist as 400, the process-group kill, the bounded queue, a write whose list fails, a generic 500 with the cause in the daemon log, the pinned global store, and trailing-newline handling.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76VHM2HSRW9BEXED3XHHHFC


## Stats: 1091 lines added, 2 lines deleted, 16 files changed

```text
pana/CONTRIBUTING.md
pana/README.md
pana/SPEC.md
pana/src/api/routes.ts
pana/src/secrets/handlers.ts
pana/src/secrets/index.ts
pana/src/server/handlers.ts
pana/src/server/index.ts
pana/src/server/runtime.ts
pana/test/browser/settings.spec.ts
pana/test/harness/index.ts
pana/test/secrets.test.ts
pana/web/app.js
pana/web/index.html
pana/web/perf.js
pana/web/style.css

```

## @joshbeckman committed a change on Thursday (2026-11-12) at 03:19:49

feat(pana): set s secrets from the settings page

A credential had to come through a terminal, which a phone does not have.
The Settings page now lists the names in the user's `s` store and sets,
replaces, or removes one.

pana never keeps the value: it passes `{name, value}` to `s set -f NAME
--stdin`, so nothing lands in argv, and it never reads one back. GET
/secrets answers names only. A missing, hung, or broken `s` reads as
unavailable on the page instead of a failed page.

The test harness defaults to an in-memory store so no test touches the
developer's own secrets; the store tests run a stand-in `s`, and one runs
the real binary against a throwaway S_FILE.

## @joshbeckman committed a change on Thursday (2026-11-12) at 03:56:44

fix(pana): never display a secret value in the settings page

The panel had a Show toggle. It only revealed the draft in the field, but
the value should not be renderable by pana at all: the field stays masked,
the toggle is gone, and the only control over it is Clear.

A typed draft also empties when the page is left and after a save, so no
value sits in the DOM of a page Josh is reading.

The browser test asserts the field cannot become text, that no reveal
control exists, and that leaving the page drops the draft.

## @joshbeckman [commented on Thursday (2026-11-12) at 04:02:17](https://github.com/joshbeckman/dotfiles/pull/294#issuecomment-6814099476)

## Verdict: request changes

Reviewed at head `2f371b9` in my own worktree, against the real `s` 0.9.5 on a throwaway `S_FILE` (never the store in `~/.config/senv`). The security claims hold: the value stays out of argv, logs, error bodies, and the page; sessions get 403 on all three routes; a missing or stale bearer token gets 403; nothing reads a value back. Three findings need a fix before merge. None is a leak; each is a wrong or lost message, or a silently corrupted value.

### What I ran

- `npx tsc --noEmit`: clean.
- `npm test`: 66 files, 798 passed, 4 skipped (at `be95c82`; `2f371b9` changes only web, docs, and the browser spec). `test/secrets.test.ts` and `test/settings.test.ts` again at `2f371b9`: 20 passed, including the real-`s` test.
- `npx vitest run --config vitest.web.config.ts test/browser/settings.spec.ts` at `2f371b9`: 3 passed. One earlier run timed out in the pre-existing "edits full JSON safely" test at 25s and passed on rerun. I did not chase it.
- A throwaway browser spec at 390x844 (light and dark) with three stored names, the remove confirm open, and raw `fetch("/secrets")` calls with no token and with `Bearer nope`.
- Node scripts that drive `createSenvStore` against the real `s` with a wrong `S_KEY`, a failing `S_KEY_COMMAND`, a 20s `S_KEY_COMMAND`, a 64 KiB value, a multi-line value, and names on `s`'s own denylist.
- `strace` on `s set`, and `s` itself for name limits, trailing newlines, `./.senv` precedence, and what env it passes to a child.

### Findings

**1. The page silently corrupts a multi-line value.** `web/index.html:537` is an `<input type="password">`. A browser strips line breaks from an input's value before any script sees it. In Chrome at phone width I set the field to `"line1\nline2\nline3"` and read back `"line1line2line3"`. A PEM key pasted here is stored joined into one line, with no error, and the page cannot show it afterwards to catch the problem. `src/secrets/index.ts:39` sizes `MAX_VALUE_BYTES` for a PEM key, so this is a stated use. Through the API the value survives: I posted a four-line PEM through `createSenvStore` and `s` kept three line breaks (it strips one trailing newline). Fix: a `paste` handler that reads `clipboardData` and refuses a value with a line break, plus "one line" in the hint at `web/app.js:345`; or a masked textarea.

**2. A multi-line `s` error reaches the page as its last line, not its reason.** `src/secrets/index.ts:123` takes the last non-empty stderr line. With a wrong store password, `s set` prints three lines, and the 502 message is "Use the store's original S_KEY, or remove the old secrets first (`s rm ...`)." The headline, "password does not match the existing store", is dropped. Fix: take the first line, or the line that starts with `error:`.

**3. A 500 from the store loses its cause.** `src/secrets/handlers.ts:17` wraps a non-`SecretsError` into `new ApiError(500, "internal", "internal error")`. `src/server/app.ts:104` then reports that wrapper, not the original. I passed a store whose `set` throws `TypeError("secret value is a Symbol")`; `t.reports` holds `{what: "request POST /secrets", message: "internal error", name: "ApiError"}`. API-01 says the detail goes to panad's log; here it goes nowhere. Fix: rethrow the original error and let `toApiError` make the 500.

**4. The timeout kills `s` but not its password command.** `src/secrets/index.ts:96` sends SIGKILL to `s` only. With `S_KEY_COMMAND="sleep 20 && echo pw"` and `timeoutMs: 500`, the call rejected at 509ms and `sleep 20` was still running. On a Mac with a locked keychain that is one orphaned `security find-generic-password` per attempt, and a phone user who retries makes several. Fix: `detached: true` and `process.kill(-child.pid, "SIGKILL")`.

**5. `available: true` means `s list` ran, not that a write can succeed.** `s list` and `s rm` need no password; only `s set` does. With `S_KEY_COMMAND=false`, `createSenvStore().list()` resolves with the names, so `GET /secrets` answers `available: true`, and `set()` then fails with "S_KEY command failed (exit 1)", which the route makes a 502. That message is true, so the page is not wrong, but `SPEC.md:54` says a broken `s` reads as `available: false`, and it does not. Reword the SPEC item; there is no cheap probe without a decrypt.

**6. `s` refuses names pana accepts, and pana calls it 502.** `s` 0.9.5 has a denylist: `PATH`, `SHELL`, `IFS`, `ENV`, `BASH_ENV`, `LD_PRELOAD`, `LD_LIBRARY_PATH`, `DYLD_INSERT_LIBRARIES`, `NODE_OPTIONS`, `PYTHONPATH`, `PERL5OPT`, `S_KEY`, `S_FILE`, `S_KEY_COMMAND` all fail with "unsafe env name: PATH — cannot enter the store". Through `createSenvStore` that is code `failed`, so the route answers 502 `secrets_unavailable` for a request the caller got wrong. Map a stderr line matching `unsafe env name|invalid key` to `invalid_name`, which is already 400.

**7. `"\n"` passes `secretValueError` and `s` stores an empty value.** `src/secrets/index.ts:54` checks `length === 0`; `s --stdin` strips one trailing newline, so `"\n"` becomes `""`. Only the API can send it, since the input cannot hold a newline. Trim the trailing newline before the length check, or document that `s` does.

**8. A write that succeeds can still answer an error.** `src/secrets/handlers.ts:77` lists after a set. I passed a store whose second `list` throws; `POST /secrets` answered 500 after the set had succeeded, and the page would show an error for a secret that was saved. Low: the list just ran and will usually run again. Answering `names: undefined` and letting the page reload is one option.

### Verified and fine

- The value never enters argv: `test/secrets.test.ts:90` reads the fake `s`'s argv log. `src/server/log.ts` still logs route metadata only. No 400 or 502 message echoes a value; `s` stderr names the key, not the value.
- No route returns a value. `s get` refuses without a TTY (`error: refusing to show secret without a TTY`), checked piped and with stdin from `/dev/null`.
- Sessions: 403 on GET, POST, DELETE via `Pana-Caller`. From the page, `fetch("/secrets")` with no `authorization` header and with `Bearer nope` both got 403; the app's `api()` attaches the token.
- `s` writes with tmp file, `fsync`, `rename`, then `fsync` on the directory (strace). A kill mid-write leaves the old store intact. There is no lock, so a terminal `s set` that lands between pana's read and rename is lost; the window is milliseconds and pana's queue cannot close it. Acceptable, and worth one sentence in the header comment.
- Limits: `s` accepts a 129-character name and a 1 MiB value, so pana's 128 and 64 KiB are stricter than `s` and the 64 KiB path works end to end through `createSenvStore` (65536 bytes read back inside the child).
- Harness default of an in-memory store is the right trade: the alternative is every test touching the developer's store. `test/secrets.test.ts` exercises the spawn path with a stand-in `s` and the installed binary.
- The browser assertions are real: `value.value === ""` after save, `body.textContent` without the value, the row list, the confirm box before remove, and `t.runtime.secrets.list()` on both sides.
- Phone width, light and dark: rows wrap a long name, Remove is reachable with a thumb, the confirm opens inside the row with Cancel focused. Controls are 28 to 32px tall, which matches `--control-h` elsewhere.
- House rules: `SPEC.md` item and API table rows, `web/perf.js` route names, `src/secrets/{index,handlers}.ts`, CONTRIBUTING ownership row, no new config key, no second secrets writer.

### Nits

- `src/secrets/index.ts:10` says the password comes from "`S_KEY_COMMAND` (or `S_KEY`)". Under `bin/panad-service`, panad is a child of `s KEYS -- panad`, and `s` strips `S_KEY` and `S_FILE` from the child's env while passing `S_KEY_COMMAND` through (checked with `s K -- env`). Only `S_KEY_COMMAND` reaches panad there; the running daemon's env has it (names only, PID 1059016).
- `s` prefers `./.senv` in its cwd over `~/.config/senv/senv`, and `s list` merges both. panad's cwd is `$HOME` and there is no `~/.senv` today, so this is fine; a stray `s init` in `$HOME` would silently redirect the page's writes. Pinning `S_FILE` in the child env would close it.
- `src/secrets/index.ts:96` uses `setTimeout`; CONTRIBUTING's clock rule says `runtime.clock`. The store is built where the clock exists.
- `autocomplete="new-password"` on `web/index.html:537` invites iOS and Chrome to offer saving the value under the name as a login. That may be unwanted for a store whose point is that only `s` holds the value.
- The hint at `web/app.js:345` could say that `s` drops one trailing newline.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76XYBMM0C2GXAM7ASFGXWEV


## @joshbeckman [commented on Thursday (2026-11-12) at 04:06:01](https://github.com/joshbeckman/dotfiles/pull/294#issuecomment-6814165241)

## Security review (addendum to my comment above; head `2f371b9`)

Verdict stays **request changes**. One security finding needs a decision before merge (S1); S2 needs a one-line fix. Nothing here reads a value back or puts one on a log, in argv, or in the page. The value's exposure paths are the browser's own password manager, the process memory of panad and `s`, and the clipboard the user pasted from.

### Security findings, by severity

**S1 (medium). Any process running as Josh on the box can write and remove secrets through panad, with no store password.** Sessions included. Proof from my own session's `bash`: `curl --unix-socket $PANA_STATE/panad.sock http://panad/settings` with no `Pana-Caller` header answers 200; with `Pana-Caller: $PANA_SESSION` it answers 403. API-03 makes an unlabeled socket caller the user, the socket is `srw------- josh`, and `$PANA_STATE/web-token` is `0600 josh`, so `test -r` succeeds from a session too (I did not print it). The 403 in `userOnly` (`src/secrets/handlers.ts:11`) holds only for callers that name themselves. Before this PR a session could not write the store: `printf x | s set -f PROBE --stdin` from my session fails with "reading password from TTY" (the real store's mtime did not change; `secret-tool` is not installed here, and ISO-03 keeps `S_KEY_COMMAND` out of a session's env). After this PR, panad lends its `S_KEY_COMMAND` to any same-user caller. The same socket already allows `POST /settings` and `/settings/restart`, so panad was already controllable; what is new is a write into a store the rest of Josh's machine trusts (see blast radius). I do not have a clean fix: the socket cannot tell a session's `bash` from Josh's shell. Options: make the three routes TCP-only (`ctx.transport === "tcp"` in `userOnly`), which at least forces the token; refuse names in `bin/panad-service`'s `default_secrets` list so a session cannot swap the provider key panad itself runs on; and say in SPEC/README that a session on the host can reach this. At minimum the last one.

**S2 (medium). The browser is invited to keep a copy of the value.** `web/index.html:537` sets `autocomplete="new-password"` on the value field, next to a text field with a name. That is the signup pattern Chrome, Safari, and iOS use to offer "Save password?" and strong-password suggestions. An accepted prompt stores the value in the browser's password manager or iCloud Keychain under the name, a second copy outside `s` that syncs across devices. Not verified in a browser (headless CDP shows no prompt); this is documented browser behaviour. Fix: `autocomplete="off"` plus `data-1p-ignore` and `data-lpignore="true"`; Safari may still prompt, which the hint should say.

**S3 (low). A stolen token can pile up `s` processes and keychain prompts.** No rate limit; `createSenvStore` queues calls without bound (`src/secrets/index.ts:150`); each hung call lasts 15s and the kill at `:96` leaves the `S_KEY_COMMAND` child alive (proven with `sleep 20 && echo pw`: rejected at 509ms, `sleep 20` still running). On a Mac with a locked keychain, N posts are N `security find-generic-password` processes and N unlock dialogs, sequentially, for 15N seconds. Fix: kill the process group, and refuse with 503 when the queue is past a small depth.

**S4 (low). The page shows `s` stderr verbatim.** `failure()` at `src/secrets/index.ts:123` relays one stderr line as the 502 message. Every `s` 0.9.5 error I provoked names the key, never the value (`unsafe env name: PATH`, `S_KEY command failed (exit 1)`, `password does not match`, `key X not found`). A future `s` or a Rust panic could print more. Cap the line length and strip anything after the first sentence, or map known messages to fixed text.

**S5 (low, pre-existing). The 64 KiB check runs after a 25 MiB read.** `src/server/app.ts:71` buffers up to `files.maxBytes` (25 MiB default) and parses the JSON before `secretValueError` runs. A token holder can make panad hold 25 MiB per in-flight request. Same as every other JSON route; a per-route limit would fix it.

**S6 (integrity, from my first comment, item 1).** The `<input>` joins a multi-line value into one line with no error and the page cannot show it afterwards, so a PEM key is stored broken and the first sign is a failed session.

### The questions, each with how I checked

**Exposure on the wire.** TCP binds `127.0.0.1` only (`src/server/index.ts:235`; `ss -ltn` shows `127.0.0.1:8766`). The plain-HTTP URL is unreachable from another host, so there is no unencrypted path off the machine. Through Tailscale Serve the value is TLS to the node, then plaintext on loopback inside the same host. `POST /secrets` carries the value in a JSON body, never a query string, so nothing logs it in a URL. `web/sw.js:5` is a no-op fetch listener with no cache, so a stale worker cannot serve a cached page or response; `/secrets` responses are `cache-control: no-store` and hold names only. `keepalive` is used on `/stats/client` only (`web/app.js:496`). Verified by reading; the Tailscale TLS hop I did not exercise.

**Who can set a secret.** Token compare is `timingSafeEqual` after a length check (`src/server/app.ts:185`); the length is fixed at 43, so that leaks nothing. Host must be loopback or a detected Tailscale name (`app.ts:143`), unchanged by the PR. From the page, `fetch("/secrets")` with no header and with `Bearer nope` both got 403 (Chrome at 390x844). The token leaves the URL fragment on first load and lives in `localStorage` (`web/app.js:77-87`); any script on that origin, so an extension with host access, can read it: pre-existing. On the box, see S1: the socket and the token file are both reachable by every process of the user.

**Process exposure.** argv: `test/secrets.test.ts:90` reads the stand-in `s`'s argv log; with the real `s` I ran `createSenvStore().set` and read the value back only inside `s X -- sh -c '[ "$X" = ... ]'`. Request buffer: `rawBody` and `body` live on `ctx` until the request ends, then are garbage. JSON parse error: the message is fixed text, `request body is not valid JSON` (`app.ts:241`). `s` stderr: names only, as in S4. panad's log: `src/server/log.ts` writes transport, method, path, route, caller, status, duration; the path for DELETE holds the name. 500s report the error object, and `refusal()` has already replaced it with "internal error" (item 3 above), so even a thrown value could not reach the log. Core dump: the value sits in Node's heap and in `s`'s memory until each frees it; inherent, not verified. Launch URL: token only, in the fragment, `0600` on disk (WEB-01). Page: no `data-` attribute or URL ever holds the value; the only `dataset` is the row's name. After a save, `clearSecretDraft()` empties the input before `renderSecretNames` and the browser test asserts `body.textContent` has no value. Browser autofill and session restore: see S2; Chrome does not restore `type=password` on reload, and I did not test iOS.

**Anything that reads it back.** Routes: `secrets.list` returns `{names, available, maxValueBytes, error?}`, `secrets.set` and `secrets.remove` return `{names}` (`src/secrets/handlers.ts:40,60,72`); `test/secrets.test.ts:101-102` asserts the list body holds neither stored value. `s get` refuses without a TTY (`error: refusing to show secret without a TTY`), checked piped and with stdin from `/dev/null`. A failed `s set` with a wrong password or a failing key command yields a message with no value (ran both). Test helpers: `createMemorySecrets` keeps values in a closure and exposes `list` as names only. Nothing else in the diff touches a value after `child.stdin.end(value)`.

**Denial and misuse.** See S3 and S5. Concurrent writes: pana serialises its own calls; `s` writes tmp file, `fsync`, `rename`, `fsync` on the directory (strace), so a kill mid-write leaves the old store whole. `s` takes no lock, so a terminal `s set` that lands inside pana's read-rename window is overwritten; milliseconds, and nothing pana can do. A malformed body stops at 400 before `spawn` (ten shapes in `test/secrets.test.ts:128-139`, all 400, store untouched). A 64 KiB value reaches `s` and is stored whole; `s` itself accepts 1 MiB, so pana's limit is the binding one.

**Blast radius.** The token already allowed `POST /settings` and `/settings/restart`. It now also allows replace and remove of any entry in Josh's global `s` store. That store feeds `bin/panad-service` (provider keys injected at start, so remove + restart is a provider outage, and replace + restart runs panad on someone else's key), every `s NAME -- cmd` in Josh's own shell and scripts, and `s curl` headers. A replaced credential is a poisoned one: a swapped cloud key sends Josh's own uploads to the attacker's account. `s` installs a pre-commit hook that runs `s scan`, which compares file contents against stored values and executes nothing from them, so no code runs from a value. Reads stay impossible through pana. So the widening is: from "control pana" to "write any credential Josh's machine trusts, without the password". That is why S1 matters more than it would for a pana-only store.

### Not verified

- The Tailscale Serve hop and the Host header it sends.
- Browser password-manager prompts on iOS or desktop Safari.
- Whether iOS restores a password field after the PWA is evicted and resumed.
- The macOS `security` behaviour on a locked keychain; the orphan was proven with `sleep`.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76XYBMM0C2GXAM7ASFGXWEV


## @joshbeckman committed a change on Thursday (2026-11-12) at 04:14:53

fix(pana): answer the secrets review, and close the socket path

From the fable review of PR 294 (head 2f371b9):

- The value field is one line, so a pasted multi-line value would be stored
  joined with no error. A paste with line breaks is refused, a trailing
  newline is dropped, and the hint says the field is one line.
- `s`'s refusal is now its `error:` line, capped at 300 characters, not the
  last line of advice below it. A name `s` refuses at its own door (its
  denylist: PATH, LD_PRELOAD, S_KEY_COMMAND, ...) is 400, not 502.
- A non-store error is rethrown so panad logs the cause instead of a
  wrapper saying "internal error".
- The timeout kills `s`'s process group, so a stuck S_KEY_COMMAND dies too.
  More than four waiting calls is 503 instead of an unbounded queue.
- A write that landed, followed by a failed list, answers 200 with
  `names: null` and the page reloads rather than reporting "not saved".
- A value of only newlines is refused: `s --stdin` would store nothing.
- The child is pinned to the global store so a stray `~/.senv` cannot take
  the page's writes, and the timeout runs on the runtime clock.
- The three routes are TCP only. On the socket an unlabeled caller is the
  user, so any same-user process, a session's bash included, would
  otherwise write the store without the password. The token is now
  required, and SPEC/README say what a same-user process can still do.
- The value field drops `autocomplete="new-password"` for `off` plus the
  1Password and LastPass ignore hints, so the browser is not invited to
  keep its own copy.

## @joshbeckman [commented on Thursday (2026-11-12) at 04:20:24](https://github.com/joshbeckman/dotfiles/pull/294#issuecomment-6814410364)

## Re-check of `06dcd2e`: approve with nits

Every finding from my two comments is fixed or documented, and the two things I was asked to break held.

### What I ran

- `npx tsc --noEmit`: clean. `npm test`: 66 files, 806 passed, 4 skipped. `npx vitest run --config vitest.web.config.ts test/browser/settings.spec.ts`: 3 passed, including the synthetic multi-line paste and the `autocomplete="off"` assertion.
- A Node probe of `senvChildEnv` and `createSenvStore` against the real `s` 0.9.5, with a scratch `$HOME`, a `./.senv` in the cwd, an exported `S_FILE`, and a `~/.senv` with no global store.
- A throwaway harness test: 12 concurrent `POST /secrets` against a stand-in `s` that sleeps 300ms per call, then 5 more after the queue drained, then a `GET`.

### The pinned `S_FILE`

Held in both cases that matter here.

- panad env without `S_FILE`, cwd holding its own `.senv`, global store present: `senvChildEnv` pins `S_FILE` to `~/.config/senv/senv`; `set` grew the global store (743 to 816 bytes) and left `./.senv` at 3 bytes. Without the pin, `s set` from the same cwd writes the local file (I showed that in the first review).
- Exported `S_FILE=other.senv`: the write went to `other.senv` and the global store does not hold the name. As documented.
- No global store, `~/.senv` present: `S_FILE` stays unset, and `set` wrote to `<cwd>/.senv`. For panad that cwd is `$HOME`, so `~/.senv` takes the writes, and a session whose cwd is a worktree reads `<worktree>/.senv` then global and never sees them. Josh's box has the global store, so this is the fresh-machine case only. Nit: the README could say that the page needs the global store to exist.
- The pin is computed once at startup (`src/server/index.ts:150`). A global store created after panad started is not pinned until a restart. Nit.

### The 503 queue

Count is right and nothing wedges.

- 12 concurrent posts: 5 answered 200, 7 answered 503 `secrets_busy` ("too many secret calls are already waiting on s"). The stand-in `s` saw 10 calls: 5 `set` and 5 follow-up `list`. That is 1 running plus 4 waiting, which matches "more than four waiting is 503".
- 5 more posts after the drain: all 200. `pending` went back to 0; the counter does not leak on either the resolved or rejected path.
- `GET /secrets` afterward: 200, `available: true`.
- `t.reports` was empty: no follow-up list hit the queue in this shape, because each list enqueues after its set finished and freed a slot.

One nit, not security: `secrets.list` at `src/secrets/handlers.ts` still turns every non-invalid `SecretsError` into 200 `available: false`, and `busy` is one of them. A `GET` that lands while four calls wait answers `available: false` with the busy message, and `renderSecrets` then disables the name, value, and Save controls until Refresh. The same happens when a follow-up list is busy: `names: null`, the page reloads, the reload is busy, the form locks. Let `busy` fall through to `refusal()` so `GET` answers 503 like the writes, and the page keeps the form enabled with the error.

### The other fixes, checked

- TCP only: `test/secrets.test.ts` posts over the socket with and without `Pana-Caller` and gets 403 on all three routes; the running daemon still answers the socket with 200 for `/settings`, so the gate is the route's, as intended. README and SPEC say a same-user process can still use the token file.
- `refusal()` rethrows: `t.reports` holds the `TypeError` message. API-01 satisfied.
- `detailLine` picks the `error:` line, capped at 300. The wrong-password case now reads "password does not match the existing store …".
- `unsafe env name|invalid key` is `invalid_name`, 400.
- `withoutTrailingNewlines` runs before the emptiness check and before stdin. `s` itself strips only `\n` and keeps a trailing `\r` (`printf 'abc\r\n'` stores `abc\r`), so pana is slightly stricter than `s`; that is the better behaviour and only a doc nuance.
- Process-group kill: `detached: true` and `process.kill(-pid)`, with the test asserting the inner `sleep` is gone.
- `autocomplete="off"`, `data-1p-ignore`, `data-lpignore="true"`: Chrome and Safari may still offer their built-in save for a `type="password"` field. Nothing more the page can do.
- Paste refusal works for the `paste` event. A value inserted by iOS AutoFill, "Scan Text", or a keyboard clipboard that uses `insertText` rather than a paste event would bypass it and be joined. I could not test those; the hint's "One line per value" covers the user who reads it.
- S5 (25 MiB body before the 64 KiB check): leaving it is fine. A per-route body cap is a change to `app.ts` for every route and belongs in its own PR.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M76XYBMM0C2GXAM7ASFGXWEV


## @joshbeckman committed a change on Thursday (2026-11-12) at 04:23:20

fix(pana): a busy secret queue answers 503, not an unavailable store

From the re-review of PR 294: `secrets.list` folded every store error into
200 `available: false`, so a full queue looked like a store that was gone
and the page disabled the form until a manual refresh. Only an unavailable
or failed store reads that way now; `busy` keeps its 503.

### ✅ @joshbeckman merged this on Thursday (2026-11-12) at 04:44:18

### 🔒 @joshbeckman closed this on Thursday (2026-11-12) at 04:44:18



## Merged on Thursday (2026-11-12) at 04:44:18
