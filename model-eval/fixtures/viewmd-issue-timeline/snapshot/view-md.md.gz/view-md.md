# Issue #224: [fix(bin/free-space): never expand an empty cache path into rm -rf /*](https://github.com/joshbeckman/dotfiles/issues/224) opened by @joshbeckman on Wednesday (2026-11-04) at 23:57:02

**Severity:** HIGH_BUG (data loss)
**Where:** `bin/free-space:211-216`

## What happens

The script computes its gate from one `brew --cache` call and then runs `rm -rf "$(brew --cache 2>/dev/null)"/*`. If the second call fails or returns empty, the expansion is `/*` and `--apply` deletes everything the user can delete.

## Fix

Capture the path once into a variable, use it for both the gate and the delete, and refuse when it is empty or not an absolute path under the user's cache (`[ -n "$cache" ] && [ -d "$cache" ]`). Or drop the manual delete and rely on `brew cleanup`.

## Acceptance

- [ ] an empty or failing `brew --cache` aborts before any `rm`
- [ ] `--apply` still cleans the real cache in a test with a stubbed `brew`

Found by the deepsec full-repo scan of 2026-11-04 (`dotfiles` project; pana://beacon.joshbeckman.org/threads/01M6M4E7FD889M8B1HE1MTJHW8).

Co-authored-by: AI pana://beacon.joshbeckman.org/sessions/01M6M42WDD66T2QBXVD3Q0X94R


### 🏷️ @joshbeckman added labels `bug`, `deepsec` on Wednesday (2026-11-04) at 23:57:04

### 🔗 @joshbeckman mentioned this in [#239: fix(free-space): never expand an empty brew cache path into rm -rf /*](https://github.com/joshbeckman/dotfiles/pull/239) on Thursday (2026-11-05) at 00:05:08

### 🔒 @joshbeckman closed this on Saturday (2026-11-07) at 13:18:47


## Labeled: bug, deepsec

## Closed on Saturday (2026-11-07) at 13:18:46
