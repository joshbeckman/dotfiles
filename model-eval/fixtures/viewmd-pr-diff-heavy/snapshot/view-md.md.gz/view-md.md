# Pull Request #280: [fix(pana): a session may define a check, and it runs in that session's box](https://github.com/joshbeckman/dotfiles/pull/280) opened by @joshbeckman on Monday (2026-11-09) at 01:49:39

## The 403 being removed

A session that owns a PR wants a five-minute poll that only wakes it when something changed:

```
$ pana schedule wake --cron "*/5 * * * *" --check ./changed.sh --note "check PR 300"
forbidden: only the user may set a check on a schedule
```

The same refusal hit a metric:

```
only the user may define a check on a metric
```

#201/#256 was right to take panad's environment away from a check: it runs on panad's clock with
panad's identity, so it must not see `process.env` (provider keys) or start in panad's cwd. But it
also made `check`/`checkCwd` the user's alone, and that removed the legitimate case above. The
definition is not the risk; the run is. So a session may define a check again, and the check runs
where that session's `bash` runs.

## The confinement a session check now gets

- **Same environment as its `bash`.** `runCheck` builds `PanaExecutionEnv` with the authoring
  session's id and scratch, so the child sees exactly `PANA_ENV_NAMES` (`PATH`, `HOME`, `USER`,
  `LANG`, `TERM`, `PANA_SESSION`, `PANA_THREAD`, `PANA_STATE`, `PANA_SCRATCH`,
  `PANA_BROWSER_SESSION`) and never panad's `process.env`.
- **Same guard.** The checkout guard and any `tools.protectCheckouts: "sandbox"` mounts treat the
  check as that session's command: it cannot use a cwd in a checkout it does not own, and in
  sandbox mode an unowned checkout is mounted read-only for it.
- **Its own box as cwd.** `sessionBox` names the roots: the session's scratch, its state
  worktrees, its memory worktree, and every adapter tree its ownership receipt names. A cwd
  outside them is 400 `invalid_check_cwd` naming the box while the check is defined, and a
  `failed` result rather than a run if a stored row ever names one. The default is the session's
  scratch, never panad's cwd.
- **The author's box, not the schedule creator's.** The author is stored beside the check
  (`check_authors`), so a check can never run under another session's identity.
- **Unchanged limits.** The 30-second timeout on the runtime clock, 8 KiB retained per stream, and
  the killed process group. The user's own check keeps the user's cwd and no session identity.

## Before and after

| as a session | before | after |
| --- | --- | --- |
| `POST /schedules {check}` | 403 `only the user may set a check on a schedule` | 201, `checkCwd` = the session's scratch |
| `POST /schedules/:id {check, checkCwd: "/tmp"}` | 403 | 400 `invalid_check_cwd` naming the session's box |
| `POST /schedules/:id {check}` on a peer's schedule | 403 | 200, and the check runs as **the caller**, not the peer |
| `POST /objectives/:id/metrics {check}` | 403 `only the user may define a check on a metric` | 201, runs in the session's box |
| `POST /schedules {check, checkCwd: "/home/josh/dotfiles"}` (user) | 201 | 201 (unchanged) |
| a session check whose stored cwd is the user's checkout | n/a | `failed` before spawn: "outside session …'s box" |
| the same, `protectCheckouts: "sandbox"` and a cwd in its own scratch | n/a | the write to the checkout fails on a read-only mount |

Tests, all in `test/schedule-checks.test.ts` and `test/objective-metrics.test.ts`:

- **no provider keys**: the check asserts `PANA_SESSION`, `PANA_SCRATCH`, `PWD`, and an empty
  planted `PANA_TEST_SECRET`, then prints its reading; any miss dumps `env` and exits non-zero.
- **cwd outside the box**: `/tmp` and a peer session's worktree are both 400 on create and update;
  changing only the command keeps the stored box cwd; an unrelated edit keeps cwd and author.
- **the user's checkout**: refused as a cwd before anything spawns, and in sandbox mode a write
  from the session's own scratch into a checkout exits non-zero and the file never appears.
- **the user's check**: still created with `checkCwd: process.cwd()` or a chosen directory and
  still dispatches.
- **who owns the box**: a session editing another session's schedule (which master still allows;
  #203 is PR #257, not merged) gets a check that runs with *its* `PANA_SESSION`, never the
  creator's.

## Deliberately left out

- **#203's ownership gate.** `origin/master` has no ownership check on `updateSchedule` (PR #257
  is open, and rebases this file). This change does not add one; it only guarantees that a check
  is authored by the caller, so the two changes compose. Expect a small conflict in
  `src/schedules/store.ts` whichever lands second.
- **Recreating a swept box.** A check whose session's scratch was swept fails with "the session's
  box may have been removed" rather than recreating the directory; a check must not fight the
  scratch sweep.
- **A session's explicit-cwd escape hatch (GUARD-05).** A session created inside the user's
  checkout may write there, but a check it defines may not: the box is scratch, worktrees, and
  memory only. A cron run has no user watching it.

## Checks

- `npx tsc --noEmit` clean.
- `npx vitest run` — 58 files, 709 passed, 2 skipped.
- `npx vitest run test/schedule-checks.test.ts test/objective-metrics.test.ts` — 30 passed.

Closes #279

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M6YZ5VCMYCF05QAMNBE7SYTA <josh@joshbeckman.org>


## Stats: 478 lines added, 125 lines deleted, 14 files changed

```diff
diff --git a/pana/SPEC.md b/pana/SPEC.md
index b36e2ebcd..5c61a475c 100644
--- a/pana/SPEC.md
+++ b/pana/SPEC.md
@@ -312,10 +312,10 @@ provenance is carried on PR descriptions/comments/reviews and discovered through
 - [x] **SCH-06** A scheduled session that fails posts a notice to the creator.
 - [x] **SCH-07** `schedule list [--kind]` and `schedule delete` work. A deleted schedule never fires.
 - [x] **SCH-08** A DST change fires a daily cron job once per day.
-- [x] **SCH-09** All schedule kinds (`session`, `thread`, `wake`) accept recurring `--cron` schedules with optional `--check COMMAND`, `--check-cwd DIR`, and `--stop-after-success` (API `check: string | null`, `checkCwd: string | null`, `stopAfterSuccess: boolean`, default false). These options require cron; checks must be nonempty; check cwd requires a check and an absolute directory. Without an explicit check cwd, creation captures the daemon's `process.cwd()`, not the client's or a scheduled session's cwd. Without a check, `check` and `checkCwd` are null. A check is the user's alone: a session whose create or update names one is refused with 403, because a check runs on panad's own service rather than in the session that wrote it.
+- [x] **SCH-09** All schedule kinds (`session`, `thread`, `wake`) accept recurring `--cron` schedules with optional `--check COMMAND`, `--check-cwd DIR`, and `--stop-after-success` (API `check: string | null`, `checkCwd: string | null`, `stopAfterSuccess: boolean`, default false). These options require cron; checks must be nonempty; check cwd requires a check and an absolute directory. Without a check, `check` and `checkCwd` are null. A check belongs to the schedule, so whoever may change the schedule may set or clear it: the user for any schedule, and a session for the one it created (#203). A check is defined once and then runs on panad's own clock, so its author decides where it runs. The user's check runs at its recorded cwd, which defaults at creation to the daemon's `process.cwd()`, not the client's. A session's check runs in that session's box (SCH-12): its cwd must be its scratch, a worktree it owns, or its memory worktree, defaults to its scratch, and any other cwd is 400 `invalid_check_cwd` naming the box; the box is the author's, never the schedule creator's. A write that leaves the check alone keeps its command, cwd, and author, so an unrelated edit never re-homes a check.
 - [x] **SCH-10** Before dispatch, a check exiting 0 passes and dispatches the scheduled action; exit 1 means not ready and skips that occurrence. Each result is persisted and exposed as `lastCheck` in list/detail responses: `{checkedAt, status: "passed" | "not_ready" | "failed", exitCode, signal, stdout, stderr, error}`, or null before any check. A skipped occurrence leaves the recurring schedule active for its next future time.
 - [x] **SCH-11** Any other check exit code, signal, timeout, or execution error records `failed`, skips dispatch, and posts a failure notice to the creator. No session is created or woken for a not-ready or failed check; exit 1 produces no failure notice.
-- [x] **SCH-12** Checks run `bash -c COMMAND` in the clean session environment (SCH-12's own additions: only `PANA_ENV_NAMES` and the checkout guard, through `PanaExecutionEnv`, exactly as a session's `bash`; never panad's own `process.env`, so provider credentials are out of reach) with the recorded check cwd, with a 30-second timeout and at most 8 KiB retained per stdout/stderr stream. Timeout/shutdown settles without waiting for pipe EOF and kills the ordinary process group. Checks must not daemonize, enable job control, or move children to other groups; escaped children are not guaranteed to be terminated. Check output is diagnostic only, never added to agent prompts.
+- [x] **SCH-12** Checks run `bash -c COMMAND` in the clean session environment (SCH-12's own additions: only `PANA_ENV_NAMES` and the checkout guard, through `PanaExecutionEnv`, exactly as a session's `bash`; never panad's own `process.env`, so provider credentials are out of reach) with the recorded check cwd, a 30-second timeout, and at most 8 KiB retained per stdout/stderr stream. A session's check is that session's `bash` in every respect: the environment carries its `PANA_SESSION` and `PANA_SCRATCH`, the guard and any sandbox mounts treat it as that session's command, and a cwd outside the session's box records `failed` rather than running elsewhere, as does a box that no longer exists (a swept scratch). The user's check carries no session identity and runs where the user chose. Timeout/shutdown settles without waiting for pipe EOF and kills the ordinary process group. Checks must not daemonize, enable job control, or move children to other groups; escaped children are not guaranteed to be terminated. Check output is diagnostic only, never added to agent prompts.
 - [x] **SCH-13** Checks for different schedules run concurrently, without overlap of a single schedule's check/dispatch. Missed cron occurrences continue to skip rather than replay, including after restart.
 - [x] **SCH-14** `--stop-after-success` finishes a recurring schedule only after successful dispatch, not after a passing check alone. It works with or without a check; not-ready/failed checks or a failed dispatch do not finish it. Dispatch success means the action was submitted, not that the resulting session completed successfully.
 - [x] **SCH-15** Every schedule kind has a persisted display `subject`, separate from its action payload. API create/update accepts an optional top-level subject; session/thread create and wake CLI commands accept `--subject`, and `pana_schedule_wake` accepts `subject`. Explicit nonempty strings are collapsed to one line, cut at a word boundary when one is near enough to keep, and limited to 80 Unicode code points; invalid/empty values return 400. List/detail include the subject. Missing subjects start with the description's first nonempty line (prompt/body/note), limited to 80 characters, and work without a subject model. Labels never leak into the dispatched payload; `payload.subject` remains independent.
@@ -514,7 +514,7 @@ read, the way a thread's working chip is (UX-09).
 ### Metrics, reports, artifacts
 
 - [x] **OBJ-25** A metric is declared by `objective_metrics`: `name` (a slug of `[a-z0-9-]`, 1 to 40 long), `unit`, `direction` (`up` or `down`), `target` nullable, `aggregation` (`raw` or `mean`), `window` (such as `7d`, used only with `mean`), and its optional check columns (OBJ-26). Its `baseline` is its first reading, never a number typed into a charter or a form, and a null `target` means the objective has nothing to finish (the infinite case) and reports no progress. `pana objective metric add` and `metric set --value V [--source S]` (`POST /objectives/:id/metrics`, `/metrics/:name/readings`) append readings; the latest reading per metric is its current value. `metric_readings` is append-only (`objective_id`, `name`, `at`, `value`, `source`); no code path issues `UPDATE` or `DELETE` on it, and a test greps the source as EDT-04 does.
-- [x] **OBJ-26** A metric may carry its own check, which reads the value from the world instead of trusting the lead. The check is part of the metric definition (`check`, `checkCwd`, `checkEvery` or `checkCron`, `nextCheckAt`, `lastCheck` in the SCH-10 shape), and the scheduler runs it on `runtime.clock` without any session, so a daily measurement costs nothing and needs no agent awake; this adds no schedule kind. Check execution keeps SCH-09 through SCH-12's semantics unchanged: the same runner, the clean session environment rather than panad's own, the recorded check cwd, a 30-second timeout, 8 KiB retained per stream. A metric's check is the user's alone, like a schedule's (SCH-09). Exit 0 appends one reading with `source: "check"`; exit 1 appends nothing and is not a failure; a non-numeric stdout, any other exit code, a signal, a timeout, or an execution error records `failed` on `lastCheck`, appends nothing, and posts one notice to the user. Check output never reaches a lead's prompt.
+- [x] **OBJ-26** A metric may carry its own check, which reads the value from the world instead of trusting the lead. The check is part of the metric definition (`check`, `checkCwd`, `checkEvery` or `checkCron`, `nextCheckAt`, `lastCheck` in the SCH-10 shape), and the scheduler runs it on `runtime.clock` without any session, so a daily measurement costs nothing and needs no agent awake; this adds no schedule kind. Check execution keeps SCH-09 through SCH-12's semantics unchanged: the same runner, the clean environment rather than panad's own, the recorded check cwd, a 30-second timeout, 8 KiB retained per stream. A metric's check belongs to whoever declared it: the user's runs where the user chose, and a session's runs in that session's box with its cwd confined the same way as a schedule's check (SCH-09, SCH-12). Exit 0 appends one reading with `source: "check"`; exit 1 appends nothing and is not a failure; a non-numeric stdout, any other exit code, a signal, a timeout, or an execution error records `failed` on `lastCheck`, appends nothing, and posts one notice to the user. Check output never reaches a lead's prompt.
 - [x] **OBJ-27** A metric's progress is its aggregated value against its target from its baseline. With `aggregation: raw` the current value is the latest reading; with `mean` and a `window` it is the mean of the readings inside that trailing window, so a noisy daily measurement (weight, energy, paint time under load) reads as a trend rather than a sawtooth. `direction` decides which way is progress, and `unit` is rendered with every value. A window with no readings in it reports the metric as stale rather than at zero.
 - [x] **OBJ-28** Progress is per metric and never aggregated. `GET /objectives/:id/metrics` returns each metric's readings, target, and current value; the objective view draws one line per metric with its target and counts "3 of 5 at target". No percent-to-target total is stored or shown, because a single averaged number across mixed units becomes the lead's target and the user's only glance.
 - [x] **OBJ-29** A target and a baseline may be set or changed only by the user, and only by appending an `objective_events` row; a session's attempt returns 403. An objective launched with no target on any metric can gain one later and become finite, and a target can be removed to make it infinite again, so the infinite case is a starting point rather than a trap. Once a metric has its first reading, its `unit`, `direction`, `aggregation`, `window`, and `check` are frozen for sessions and editable only by the user, because a lead that can redefine what it is measured against can report anything. Its `name` is immutable for everyone, because `metric_readings` is keyed by it (OBJ-25); a rename is a new metric.
@@ -553,7 +553,7 @@ own worktree or in its scratch is doing what it was told; a session in the user'
 - [x] **GUARD-03** `pana worktree add REPO [--branch NAME] [--name NAME]` (`POST /worktrees`, sessions only, 201 when created and 200 when reused) resolves `REPO` to its git top level, creates `<state>/worktrees/<session>/<name>`, and prints that path. The branch defaults to `pana/<session>/<name>` when that name is available. Generated names avoid exact and slash-prefix collisions with local branches and cached remote-tracking refs, falling back to `pana-<session>-<name>` and then numeric suffixes (`-2`, `-3`, …). Profile-created and managed worktrees use the same chooser. Selection is offline: it does not fetch, so unseen remote changes and concurrent ref creation can still cause a later Git rejection. An existing worktree is reused; an explicitly requested existing branch is also reused rather than renamed. It runs in panad to register session ownership and create through the supported lifecycle, including when sandbox mounts make the shared Git directory read-only to the session. An explicitly requested `branch` must be a name Git accepts: no leading `-`, and none of space, `~`, `^`, `:`, `?`, `*`, `[`, `\`, `..`, `@{`, or a part ending `.lock`. Every Git call on the resolved repository, and every configured adapter, runs in a built environment instead of panad's: no inherited `GIT_DIR`, `GIT_WORK_TREE` or `GIT_CONFIG_*` can point it at another repository, and `core.fsmonitor=false`/`core.hooksPath=/dev/null` keep a repository's own config from running code as panad. The destination directory is made by pana before Git populates it, so a symlink planted after validation fails instead of redirecting the checkout.
 - [x] **GUARD-04** The set of primary checkouts is a scan, not a config list: every directory with a `.git` marker under HOME to depth 5, skipping `node_modules`, `Library`, media and cache directories, and `.local` (pana's own state, whose worktrees are where writing belongs). Configured managed roots and state worktree roots are scanned independently of HOME; ownership receipts additionally protect new peer trees immediately. The scan result is cached for ten minutes, so a repository cloned outside pana since panad started is protected within that window, and the scan costs one directory walk per ten minutes rather than per command.
 - [x] **GUARD-05** The escape hatch is the session's own cwd: a session created in a checkout (`--cwd /home/josh/dotfiles`, or that checkout's subdirectory) writes there, that checkout is not mounted read-only for it, and a command may `cd` into it. `tools.protectCheckouts: "off"` turns the guard off entirely. `pana/prompt.md` tells every session to edit a repository in a worktree, to make one with `pana worktree add`, and that reads of the user's checkout are still allowed.
-- [x] **GUARD-06** The default `guard` mode checks file-tool write paths and the actual execution cwd, not shell-command text. There is no checkout command denylist/allowlist or Git/sed/shell parser. A session normally starts in scratch and explicitly creates/reuses an owned worktree before repository changes. Arbitrary Bash writes from scratch are not prevented without a supported filesystem sandbox; policy and docs state this limit. File-tool ownership checks, symlink resolution, explicit-cwd rules and peer protection remain independent of Bash syntax.
+- [x] **GUARD-06** The default `guard` mode checks file-tool write paths and the actual execution cwd, not shell-command text. A check that a session defined runs through this same guard as that session's own command, in its box (SCH-09, SCH-12). There is no checkout command denylist/allowlist or Git/sed/shell parser. A session normally starts in scratch and explicitly creates/reuses an owned worktree before repository changes. Arbitrary Bash writes from scratch are not prevented without a supported filesystem sandbox; policy and docs state this limit. File-tool ownership checks, symlink resolution, explicit-cwd rules and peer protection remain independent of Bash syntax.
 
 - [x] **GUARD-07** Machine-local `worktreeAdapters` match a repository's canonical shared git directory and specify an absolute managed root, optional relative checkout subdirectory, and executable argv with `{name}`, `{branch}`, `{path}`, `{repo}` placeholders. `name` includes the session ID and is lowercase for external adapters; branch spelling and ordinary state-layout names remain unchanged. Both GUARD-03 and SES-04 use the adapter without a shell or fallback; failures report `worktree_adapter_failed`. Creation verifies the exact checkout root, shared repository, worktree-specific metadata back-pointer and branch before publishing a retained ownership receipt outside scratch. External pre-existing unowned destinations, repository collisions and symlinked destinations fail closed. Concurrent requests for one destination serialize; owned retries reuse it. Receipts permit file-tool writes and actual execution cwd only for that session and checkout; peer file-tool writes and implicit-cwd execution stay refused. Guard mode does not classify explicit Bash paths or fast-forward commands. Each shell invocation reads one ownership snapshot, reused for cwd checks and optional sandbox mounts. Ordinary state-layout trees remain compatible without receipts. No project tree is automatically deleted or swept with scratch.
 
diff --git a/pana/src/cli/commands.ts b/pana/src/cli/commands.ts
index e9bd339a9..b1f241288 100644
--- a/pana/src/cli/commands.ts
+++ b/pana/src/cli/commands.ts
@@ -190,8 +190,8 @@ const bool = (name: string, syntax: string, description: string) => flag(name, s
 
 const RECURRING_FLAGS = [
 	string("cron", "--cron CRON", "Cron expression in the domain timezone"),
-	string("check", "--check COMMAND", "Bash readiness check before each cron dispatch: 0 ready, 1 not ready (user only)"),
-	string("checkCwd", "--check-cwd DIR", "Absolute check directory; defaults to the daemon's cwd at creation (user only)"),
+	string("check", "--check COMMAND", "Bash readiness check before each cron dispatch: 0 ready, 1 not ready"),
+	string("checkCwd", "--check-cwd DIR", "Absolute check directory; the daemon's cwd for the user, the session's scratch for a session"),
 	bool("stopAfterSuccess", "--stop-after-success", "Finish a cron schedule after its first successful dispatch"),
 ];
 
diff --git a/pana/src/db/schema.ts b/pana/src/db/schema.ts
index c9e07d255..0991f8e50 100644
--- a/pana/src/db/schema.ts
+++ b/pana/src/db/schema.ts
@@ -533,6 +533,24 @@ export const MIGRATIONS: readonly Migration[] = [
 		// primary key or reads by thread.
 		sql: `CREATE INDEX IF NOT EXISTS messages_sender_created ON messages(sender_id, created_at);`,
 	},
+	{
+		version: 16,
+		name: "check authors",
+		// SCH-09: a session may define a check again, and it runs in that session's own box. The
+		// author is the session whose box it is; a missing row is the user's own check, which keeps
+		// the user's choice of cwd. A separate table rather than a column on `schedules` and
+		// `objective_metrics` because `ALTER TABLE ... ADD COLUMN` cannot be written idempotently in
+		// SQLite, and DB-03 requires every migration to re-run cleanly; `scope` names its owner:
+		// `schedule:<id>` or `metric:<objective>/<name>`. Rows are deleted with the schedule, and a
+		// spent wake's row goes with it, so this table tracks live checks rather than history.
+		sql: `
+			CREATE TABLE IF NOT EXISTS check_authors (
+				scope       TEXT PRIMARY KEY,
+				session_id  TEXT NOT NULL,
+				updated_at  INTEGER NOT NULL
+			);
+		`,
+	},
 ];
 
 /** The highest migration number the code knows how to apply. */
diff --git a/pana/src/objectives/cli.ts b/pana/src/objectives/cli.ts
index 713b7e4aa..7848e2a6d 100644
--- a/pana/src/objectives/cli.ts
+++ b/pana/src/objectives/cli.ts
@@ -236,8 +236,8 @@ export const OBJECTIVE_COMMANDS: readonly CommandSpec[] = [
 			string("target", "--target N", "The value that finishes the metric; omitted, it is infinite"),
 			string("aggregation", "--aggregation raw|mean", "Latest reading, or a trailing mean"),
 			string("window", "--window WINDOW", "The trailing window for a mean, such as 7d"),
-			string("check", "--check COMMAND", "Read the value from the world instead of trusting the lead (user only)"),
-			string("check-cwd", "--check-cwd DIR", "Absolute directory the check runs in (user only)"),
+			string("check", "--check COMMAND", "Read the value from the world instead of trusting the lead"),
+			string("check-cwd", "--check-cwd DIR", "Absolute directory the check runs in; a session's check stays in its own box"),
 			string("check-every", "--check-every DURATION", "Run the check every this long, such as 1d"),
 			string("check-cron", "--check-cron CRON", "Run the check on a cron schedule"),
 		],
diff --git a/pana/src/objectives/metric-checks.ts b/pana/src/objectives/metric-checks.ts
index 12d477996..2bce31d4b 100644
--- a/pana/src/objectives/metric-checks.ts
+++ b/pana/src/objectives/metric-checks.ts
@@ -18,7 +18,8 @@
 // by moving that time forward inside one write (so a restart or a second timer cannot run the
 // same occurrence twice), then runs it.
 
-import { checkHost, runCheck, type CheckResult } from "../schedules/check.ts";
+import { runStoredCheck, type CheckResult } from "../schedules/check.ts";
+import { checkAuthor, metricScope } from "../schedules/check-box.ts";
 import { nextCronAt, parseDuration } from "../schedules/store.ts";
 import type { Runtime } from "../server/runtime.ts";
 import { postNotice } from "../threads/index.ts";
@@ -245,12 +246,15 @@ class CheckLoop implements MetricChecks {
 		// OBJ-04: a draft has no readings, and a closed objective stops measuring. The occurrence
 		// is skipped, not replayed, so the next check is a full interval later.
 		if (claimed.phase !== "active") return;
-		const result = await runCheck(
-			claimed.check_command!,
-			claimed.check_cwd ?? process.cwd(),
+		const result = await runStoredCheck(
+			this.#runtime,
+			{
+				command: claimed.check_command!,
+				cwd: claimed.check_cwd,
+				author: await checkAuthor(this.#runtime.db, metricScope(claimed.objective_id, claimed.name)),
+			},
 			this.#runtime.clock,
 			this.#abort.signal,
-			checkHost(this.#runtime),
 		);
 		const measured = evaluated(result);
 		await record(this.#runtime, claimed, measured.result, measured.value);
diff --git a/pana/src/objectives/metrics.ts b/pana/src/objectives/metrics.ts
index cea46ccd1..eb818b7b4 100644
--- a/pana/src/objectives/metrics.ts
+++ b/pana/src/objectives/metrics.ts
@@ -26,6 +26,7 @@ import { isAbsolute } from "node:path";
 import { ApiError } from "../api/errors.ts";
 import type { Caller } from "../api/types.ts";
 import { nextCronAt, parseDuration } from "../schedules/store.ts";
+import { checkAuthor, metricScope, planCheck, saveCheckAuthor, type CheckPlan } from "../schedules/check-box.ts";
 import type { CheckResult } from "../schedules/check.ts";
 import type { Runtime } from "../server/runtime.ts";
 import { CLOSED_PHASES, objectBody, type ObjectivePhase, type ObjectiveRow } from "./schema.ts";
@@ -354,6 +355,8 @@ function windowFor(value: unknown, aggregate: MetricAggregation): string | null
 interface CheckDefinition {
 	command: string;
 	cwd: string;
+	/** The session whose box the check runs in; null is the user's own check. */
+	author: string | null;
 	every: string | null;
 	cron: string | null;
 	nextAt: number;
@@ -364,7 +367,7 @@ interface CheckDefinition {
  * schedule kind is added). Its first run is one interval after it is declared, so declaring a
  * metric never runs a command inside a request.
  */
-function checkFor(runtime: Runtime, input: Record<string, unknown>, now: number): CheckDefinition | null {
+function checkFor(runtime: Runtime, caller: Caller, input: Record<string, unknown>, now: number, stored: CheckPlan): CheckDefinition | null {
 	const command = input.check;
 	// `null` clears a check; an absent key leaves it alone. A check that is given must be a command.
 	if (command === undefined || command === null) {
@@ -380,10 +383,10 @@ function checkFor(runtime: Runtime, input: Record<string, unknown>, now: number)
 	const cron = present(input, "checkCron") ? String(input.checkCron).trim() : null;
 	if (every !== null && cron !== null) throw ApiError.badRequest("both_times", "a check takes --check-every or --check-cron, not both");
 	if (every === null && cron === null) throw ApiError.badRequest("missing_time", "a check needs --check-every or --check-cron");
-	const cwd = present(input, "checkCwd") ? String(input.checkCwd).trim() : process.cwd();
-	if (!isAbsolute(cwd)) throw ApiError.badRequest("invalid_check_cwd", "checkCwd must be an absolute directory path");
+	// SCH-09's cwd rule applies here too: a session's metric check runs in the session's own box.
+	const plan = planCheck(runtime, caller, input, stored);
 	const nextAt = cron === null ? now + parseDuration(every!) : cronNext(runtime, cron, now);
-	return { command, cwd, every, cron, nextAt };
+	return { command, cwd: plan.cwd!, author: plan.author, every, cron, nextAt };
 }
 
 // --- Authority and phase --------------------------------------------------------
@@ -414,16 +417,6 @@ function userOnly(caller: Caller, what: string): void {
 	if (caller.kind !== "user") throw ApiError.forbidden(`only the user may ${what} a metric`);
 }
 
-/**
- * OBJ-26: a check is the user's to define. It runs on a timer in panad's own service, out of reach
- * of the session that declared it, so a session that could plant one would get code execution
- * there. Clearing one (`check: null`) is a definition edit too, and is refused for the same reason.
- */
-function userOnlyCheck(caller: Caller, input: Record<string, unknown>): void {
-	if (caller.kind === "user") return;
-	if (["check", ...CHECK_FIELDS].some((field) => input[field] !== undefined)) userOnly(caller, "define a check on");
-}
-
 // --- Writes --------------------------------------------------------------------
 
 /**
@@ -436,7 +429,6 @@ export async function addMetric(runtime: Runtime, caller: Caller, value: string
 	const row = await loadObjective(runtime.db, id);
 	assertDeclarable(row);
 	if (present(input, "target")) userOnly(caller, "set a target on");
-	userOnlyCheck(caller, input);
 	assertNoTypedBaseline(caller, input);
 
 	const name = slug(input.name);
@@ -446,7 +438,7 @@ export async function addMetric(runtime: Runtime, caller: Caller, value: string
 	const aggregationValue = aggregation(input.aggregation);
 	const window = windowFor(input.window, aggregationValue);
 	const targetValue = target(input.target);
-	const check = checkFor(runtime, input, now);
+	const check = checkFor(runtime, caller, input, now, { command: null, cwd: null, author: null });
 
 	await runtime.db.atomically(async (tx) => {
 		const existing = await metricRow(tx, id, name);
@@ -470,6 +462,8 @@ export async function addMetric(runtime: Runtime, caller: Caller, value: string
 			check?.nextAt ?? null,
 			now,
 		);
+		// OBJ-26/SCH-09: the author is stored beside the check; a session's check runs in its box.
+		await saveCheckAuthor(tx, metricScope(id, name), check?.author ?? null, now);
 		await recordObjectiveEvent(tx, runtime, {
 			objectiveId: id,
 			kind: "metric.add",
@@ -593,7 +587,6 @@ export async function setMetric(
 
 	const targetTouched = input.target !== undefined;
 	if (targetTouched) userOnly(caller, "set a target on");
-	userOnlyCheck(caller, input);
 	assertNoTypedBaseline(caller, input);
 
 	const definitionTouched = ["unit", "direction", "aggregation", "window", "check", ...CHECK_FIELDS].some((field) => input[field] !== undefined);
@@ -616,7 +609,13 @@ export async function setMetric(
 			edit.window = aggregate === "raw" && input.window === undefined ? null : windowFor(input.window ?? existing.window_spec, aggregate);
 		}
 		const checkTouched = ["check", ...CHECK_FIELDS].some((field) => input[field] !== undefined);
-		if (checkTouched) edit.check = checkFor(runtime, input, now);
+		if (checkTouched) {
+			edit.check = checkFor(runtime, caller, input, now, {
+				command: existing.check_command,
+				cwd: existing.check_cwd,
+				author: await checkAuthor(runtime.db, metricScope(id, metric)),
+			});
+		}
 	}
 
 	const nextTarget = targetTouched ? target(input.target) : existing.target;
@@ -639,6 +638,7 @@ export async function setMetric(
 			push("check_every", edit.check?.every ?? null);
 			push("check_cron", edit.check?.cron ?? null);
 			push("next_check_at", edit.check?.nextAt ?? null);
+			await saveCheckAuthor(tx, metricScope(id, metric), edit.check?.author ?? null, now);
 		}
 		if (targetTouched) push("target", nextTarget);
 		if (sets.length > 0) {
diff --git a/pana/src/schedules/check-box.ts b/pana/src/schedules/check-box.ts
new file mode 100644
index 000000000..c25a60bc2
--- /dev/null
+++ b/pana/src/schedules/check-box.ts
@@ -0,0 +1,135 @@
+// The box a session-authored check runs in (SCH-09, SCH-12, OBJ-26).
+//
+// A check is defined once and then runs on panad's own clock with panad's identity, long after
+// the request that defined it returned. #201/#256 took panad's environment away from that run
+// (see `check.ts`). A session may define a check, so this file takes the rest away: the check
+// runs where the authoring session's own `bash` runs, in that session's box - its scratch, the
+// worktrees it owns, its memory worktree - and nowhere else. The user's own check keeps the
+// user's choice of cwd.
+//
+// The rule is stated once here and enforced twice from it: `planCheck` refuses a cwd outside the
+// box with a 400 while the check is defined, and `boxRefusal` (called by `runCheck`) records a
+// failure rather than executing somewhere else if a stored row ever names one.
+
+import type { SqliteExecutor } from "@earendil-works/chord/sqlite";
+import { isAbsolute, join } from "node:path";
+import { ApiError } from "../api/errors.ts";
+import type { Caller } from "../api/types.ts";
+import { realPath, under } from "../extension/checkouts.ts";
+import { ensureScratch } from "../scratch/index.ts";
+import type { Runtime } from "../server/runtime.ts";
+import { ownedPaths } from "../worktrees/ownership.ts";
+
+/** The directories a session's commands may write: its scratch and every checkout it owns. */
+export interface SessionBox {
+	/** The session whose box it is. */
+	id: string;
+	/** Where the session's commands run when nobody names a directory: its scratch (SCR-01). */
+	scratchDir: string;
+	/** Every directory a check authored by this session may use as its cwd. */
+	roots: readonly string[];
+}
+
+/** GUARD-03..07: the box of one session, read from panad's state rather than supplied. */
+export function sessionBox(runtime: Runtime, sessionId: string): SessionBox {
+	const scratchDir = join(runtime.paths.scratch, sessionId);
+	return {
+		id: sessionId,
+		scratchDir,
+		roots: [
+			scratchDir,
+			join(runtime.paths.dir, "worktrees", sessionId),
+			join(runtime.paths.memoryWorktrees, sessionId),
+			// GUARD-07: an adapter's trees live outside the state layout; the receipt names its owner.
+			...ownedPaths(runtime.paths.dir, sessionId),
+		].map(realPath),
+	};
+}
+
+/** Why `cwd` is outside a session's box, or undefined when it is inside one of its roots. */
+export function boxRefusal(box: SessionBox, cwd: string): string | undefined {
+	const path = realPath(cwd);
+	if (box.roots.some((root) => under(root, path))) return undefined;
+	return (
+		`${cwd} is outside session ${box.id}'s box, and a check a session defines runs only there: ` +
+		`its scratch (${box.scratchDir}), a worktree it owns, or its memory worktree`
+	);
+}
+
+/** The check a create or an update ends up with. */
+export interface CheckPlan {
+	command: string | null;
+	cwd: string | null;
+	/** The session whose box the check runs in; null is the user's own check. */
+	author: string | null;
+}
+
+/** The fields that name a check, as an API body carries them. */
+export interface CheckInput {
+	check?: unknown;
+	checkCwd?: unknown;
+}
+
+/**
+ * SCH-09/OBJ-26: decide which check a write ends up with. This is the one place the user's rule
+ * and a session's differ: the user may name any absolute cwd (panad's own when none is given),
+ * while a session's check is confined to its box and defaults to its scratch. A write that
+ * carries neither field leaves the stored check, its cwd, and its author alone.
+ */
+export function planCheck(runtime: Runtime, caller: Caller, input: CheckInput, existing: CheckPlan): CheckPlan {
+	const author = caller.kind === "user" ? null : caller.id;
+	if (input.check === undefined && input.checkCwd === undefined) return existing;
+	const command = input.check === undefined ? existing.command : input.check;
+	if (command !== null && (typeof command !== "string" || command.trim().length === 0)) {
+		throw ApiError.badRequest("invalid_check", "--check must be a nonempty bash command");
+	}
+	if (command === null) {
+		if (input.checkCwd !== undefined && input.checkCwd !== null && input.checkCwd !== "") {
+			throw ApiError.badRequest("invalid_check_cwd", "--check-cwd requires --check");
+		}
+		return { command: null, cwd: null, author: null };
+	}
+	// A new command keeps a cwd only when the same author chose it inside a box it still owns.
+	const keep = input.checkCwd === undefined && existing.command !== null && existing.cwd !== null && existing.author === author;
+	const cwd = keep ? existing.cwd! : (input.checkCwd ?? (author === null ? process.cwd() : ensureScratch(runtime, author)));
+	if (typeof cwd !== "string" || !isAbsolute(cwd)) {
+		throw ApiError.badRequest("invalid_check_cwd", "--check-cwd requires --check and an absolute directory path");
+	}
+	if (author !== null) {
+		const refusal = boxRefusal(sessionBox(runtime, author), cwd);
+		if (refusal !== undefined) throw ApiError.badRequest("invalid_check_cwd", refusal);
+	}
+	return { command, cwd, author };
+}
+
+// --- Stored authorship ----------------------------------------------------------
+//
+// The author is stored beside the check, keyed by what owns the check, so a check's row is the
+// same shape whether it is a schedule's or a metric's.
+
+/** The scope key for a schedule's check. */
+export function scheduleScope(scheduleId: string): string {
+	return `schedule:${scheduleId}`;
+}
+
+/** The scope key for a metric's check. */
+export function metricScope(objectiveId: string, name: string): string {
+	return `metric:${objectiveId}/${name}`;
+}
+
+/** The session whose box a stored check runs in, or null for the user's check. */
+export async function checkAuthor(db: SqliteExecutor, scope: string): Promise<string | null> {
+	const row = await db.get<{ session_id: string }>("SELECT session_id FROM check_authors WHERE scope = ?", scope);
+	return row?.session_id ?? null;
+}
+
+/** Record the session whose box a check runs in, or clear it for the user's own check. */
+export async function saveCheckAuthor(tx: SqliteExecutor, scope: string, sessionId: string | null, now: number): Promise<void> {
+	if (sessionId === null) await tx.run("DELETE FROM check_authors WHERE scope = ?", scope);
+	else await tx.run(
+		"INSERT OR REPLACE INTO check_authors (scope, session_id, updated_at) VALUES (?, ?, ?)",
+		scope,
+		sessionId,
+		now,
+	);
+}
diff --git a/pana/src/schedules/check.ts b/pana/src/schedules/check.ts
index e2784da2c..b8ce857da 100644
--- a/pana/src/schedules/check.ts
+++ b/pana/src/schedules/check.ts
@@ -5,17 +5,23 @@
 // `PanaExecutionEnv`: the child sees only `PANA_ENV_NAMES` and the checkout guard, never panad's
 // own `process.env`. That matters because a check is defined once and then runs on cron with
 // panad's identity; `bin/panad-service` injects the provider keys there, and no command pana runs
-// on its own initiative may read them. Definition is the user's alone (see `store.ts` and
-// `objectives/metrics.ts`); running it is this file's business.
+// on its own initiative may read them.
 //
-// The constraints are unchanged: the recorded cwd, a 30-second timeout on the runtime clock,
-// 8 KiB retained per stream, and a killed process group.
+// A session may define a check, so a session's check runs in that session's box
+// (`check-box.ts`): the same allowlisted environment with `PANA_SESSION` and `PANA_SCRATCH` set,
+// the same guard, and a cwd inside the session's own roots. The user's check keeps the user's
+// recorded cwd.
+//
+// The constraints are unchanged: a 30-second timeout on the runtime clock, 8 KiB retained per
+// stream, and a killed process group.
 
 import { BACKGROUND_CONTEXT, withAbortSignal } from "@earendil-works/chord/context";
+import { existsSync } from "node:fs";
 import { constants } from "node:os";
 import type { Clock, Runtime } from "../server/runtime.ts";
 import type { CheckoutGuard } from "../config/index.ts";
 import { PanaExecutionEnv } from "../extension/env.ts";
+import { boxRefusal, sessionBox, type SessionBox } from "./check-box.ts";
 
 export const CHECK_TIMEOUT_MS = 30_000;
 export const CHECK_OUTPUT_BYTES = 8192;
@@ -38,6 +44,10 @@ export interface CheckHost {
 	protectCheckouts?: CheckoutGuard;
 	/** Adapter layouts the guard also protects, as `createPanaEnv` passes them. */
 	managedLayouts?: readonly { root: string; subdir?: string }[];
+	/** Where to scan for primary checkouts (GUARD-04). HOME by default; a test names its own root. */
+	checkoutRoots?: readonly string[];
+	/** The authoring session's box, when a session defined the check (SCH-09). */
+	box?: SessionBox;
 }
 
 /** The host a check runs on, taken from the running panad. */
@@ -49,6 +59,29 @@ export function checkHost(runtime: Runtime): CheckHost {
 	};
 }
 
+/** A stored check: its command, the cwd recorded with it, and the session that authored it. */
+export interface StoredCheck {
+	command: string;
+	cwd: string | null;
+	/** The session whose box it runs in; null is the user's own check. */
+	author: string | null;
+}
+
+/**
+ * SCH-09: run a stored check on the host panad is. A session's check runs inside that session's
+ * box; the user's check runs at its recorded cwd, or panad's own when none was recorded.
+ */
+export async function runStoredCheck(
+	runtime: Runtime,
+	stored: StoredCheck,
+	clock: Clock,
+	abort: AbortSignal,
+): Promise<CheckResult> {
+	const box = stored.author === null ? undefined : sessionBox(runtime, stored.author);
+	const cwd = stored.cwd ?? box?.scratchDir ?? process.cwd();
+	return runCheck(stored.command, cwd, clock, abort, { ...checkHost(runtime), box });
+}
+
 /** The name of the signal behind an exit status the executor reported as `128 + n`. */
 function signalName(exitCode: number): string | null {
 	const number = exitCode - 128;
@@ -89,6 +122,15 @@ export async function runCheck(
 ): Promise<CheckResult> {
 	let stdout = "";
 	let stderr = "";
+	// A run pana stopped has pana's reason for it; one that never started has the executor's.
+	const failure = (error: string): CheckResult => ({
+		checkedAt: clock.now(), status: "failed", exitCode: null, signal: null, stdout, stderr, error,
+	});
+	// SCH-09: a session's check may not leave its box, even if the stored row says otherwise.
+	const refusal = host.box === undefined ? undefined : boxRefusal(host.box, cwd);
+	if (refusal !== undefined) return failure(refusal);
+	// A swept scratch is a box that is gone: say so instead of reporting a spawn error.
+	if (host.box !== undefined && !existsSync(cwd)) return failure(`the check's cwd ${cwd} does not exist; the session's box may have been removed`);
 	// Set when pana stops the run rather than the command ending it; that reason is the error.
 	let stopped: string | null = null;
 	const control = new AbortController();
@@ -104,8 +146,11 @@ export async function runCheck(
 	if (abort.aborted) cancel();
 	const env = new PanaExecutionEnv({
 		cwd,
+		sessionId: host.box?.id,
+		scratchDir: host.box?.scratchDir,
 		stateDir: host.stateDir,
 		protectCheckouts: host.protectCheckouts,
+		checkoutRoots: host.checkoutRoots,
 		managedLayouts: host.managedLayouts,
 	});
 	const execution = await env
@@ -126,10 +171,6 @@ export async function runCheck(
 			cancelTimer?.();
 			abort.removeEventListener("abort", cancel);
 		});
-	// A run pana stopped has pana's reason for it; one that never started has the executor's.
-	const failure = (error: string): CheckResult => ({
-		checkedAt: clock.now(), status: "failed", exitCode: null, signal: null, stdout, stderr, error,
-	});
 	if (stopped !== null) return failure(stopped);
 	if (!execution.ok) return failure(execution.error.message);
 	// A child the kernel killed has no exit status of its own; the executor reports the shell's
diff --git a/pana/src/schedules/scheduler.ts b/pana/src/schedules/scheduler.ts
index aca5d1cc7..284111fe5 100644
--- a/pana/src/schedules/scheduler.ts
+++ b/pana/src/schedules/scheduler.ts
@@ -13,7 +13,8 @@ import type { Runtime } from "../server/runtime.ts";
 import { admitScheduledWake, releaseLeadHold } from "../objectives/hold.ts";
 import { wakeScheduled } from "../sessions/wake.ts";
 import { createThread, postNotice } from "../threads/index.ts";
-import { checkHost, runCheck } from "./check.ts";
+import { runStoredCheck } from "./check.ts";
+import { checkAuthor, scheduleScope } from "./check-box.ts";
 import { announceWakes, wakeSessionOf } from "./live.ts";
 import { registerScheduler, unregisterScheduler } from "./registry.ts";
 import {
@@ -160,12 +161,15 @@ class ScheduleLoop implements Scheduler {
 		let delivered = false;
 		try {
 			if (row.check_command !== null) {
-				const result = await runCheck(
-					row.check_command,
-					row.check_cwd!,
+				const result = await runStoredCheck(
+					this.#runtime,
+					{
+						command: row.check_command,
+						cwd: row.check_cwd,
+						author: await checkAuthor(this.#runtime.db, scheduleScope(row.id)),
+					},
 					this.#runtime.clock,
 					this.#abort.signal,
-					checkHost(this.#runtime),
 				);
 				await recordCheck(this.#runtime, row.id, result);
 				if (this.#closed) return;
diff --git a/pana/src/schedules/store.ts b/pana/src/schedules/store.ts
index cfdb4571a..f353db426 100644
--- a/pana/src/schedules/store.ts
+++ b/pana/src/schedules/store.ts
@@ -10,8 +10,8 @@
 // one `db.write`.
 
 import type { SqliteExecutor } from "@earendil-works/chord/sqlite";
-import { isAbsolute } from "node:path";
 import type { CheckResult } from "./check.ts";
+import { checkAuthor, planCheck, saveCheckAuthor, scheduleScope, type CheckPlan } from "./check-box.ts";
 import { Cron } from "croner";
 import { ApiError } from "../api/errors.ts";
 import { isUlid, parseRef } from "../ids/index.ts";
@@ -267,32 +267,26 @@ async function wakeTarget(runtime: Runtime, caller: Caller, value: unknown): Pro
 }
 
 /**
- * SCH-09: a check is the user's to define. It runs on cron in panad's own service, out of reach of
- * the session that wrote it, so a session that could plant one would get code execution there.
+ * SCH-09: conditions belong to the schedule, never the action payload. The command, its cwd, and
+ * the session whose box it runs in come from `planCheck` (`check-box.ts`), the one place the
+ * user's cwd rule and a session's differ. `stored` is what the schedule already has, so an edit
+ * that leaves the check alone keeps its cwd and author.
  */
-function userOnlyCheck(input: ScheduleInput, caller: Caller): void {
-	if (caller.kind === "user") return;
-	if (["check", "checkCwd"].some((field) => input[field as keyof ScheduleInput] !== undefined)) {
-		throw ApiError.forbidden("only the user may set a check on a schedule");
-	}
-}
-
-/** Conditions belong to the schedule, never the action payload. */
-function conditions(input: ScheduleInput, cron: string | null) {
-	const check = input.check ?? null;
-	if (check !== null && (typeof check !== "string" || !check.trim())) {
-		throw ApiError.badRequest("invalid_check", "--check must be a nonempty bash command");
-	}
-	const stop = input.stopAfterSuccess ?? false;
+function conditions(
+	runtime: Runtime,
+	caller: Caller,
+	input: ScheduleInput,
+	cron: string | null,
+	stored: CheckPlan,
+	storedStop: boolean,
+) {
+	const plan = planCheck(runtime, caller, input, stored);
+	const stop = input.stopAfterSuccess === undefined ? storedStop : input.stopAfterSuccess;
 	if (typeof stop !== "boolean") throw ApiError.badRequest("invalid_stop_after_success", "stopAfterSuccess must be boolean");
-	if ((check !== null || stop) && !cron) {
+	if ((plan.command !== null || stop) && !cron) {
 		throw ApiError.badRequest("requires_cron", "--check and --stop-after-success require a recurring --cron schedule");
 	}
-	const cwd = input.checkCwd ?? (check === null ? null : process.cwd());
-	if (cwd !== null && (check === null || typeof cwd !== "string" || !isAbsolute(cwd))) {
-		throw ApiError.badRequest("invalid_check_cwd", "--check-cwd requires --check and an absolute directory path");
-	}
-	return { check: check as string | null, cwd: cwd as string | null, stop };
+	return { check: plan.command, cwd: plan.cwd, author: plan.author, stop };
 }
 
 // --- Reads ---------------------------------------------------------------------
@@ -412,8 +406,7 @@ export async function createSchedule(runtime: Runtime, caller: Caller, value: un
 	const now = runtime.clock.now();
 	const kind = scheduleKind(input.kind);
 	const timing = scheduleTiming(input, runtime.config.timezone, now);
-	userOnlyCheck(input, caller);
-	const condition = conditions(input, timing.cron);
+	const condition = conditions(runtime, caller, input, timing.cron, { command: null, cwd: null, author: null }, false);
 	const payload = schedulePayload(input, kind);
 	if (kind === "wake") payload.session = await wakeTarget(runtime, caller, payload.session);
 	const subject = parseScheduleSubject(input.subject);
@@ -440,6 +433,8 @@ export async function createSchedule(runtime: Runtime, caller: Caller, value: un
 			subject ?? fallbackScheduleSubject(kind, payload),
 			subject === null ? "first-line" : "manual",
 		);
+		// SCH-09: the author is stored beside the check; a session's check runs in its box.
+		await saveCheckAuthor(tx, scheduleScope(id), condition.author, now);
 		saved = await scheduleRow(tx, id);
 		return scheduleView(saved, runtime);
 	});
@@ -457,7 +452,6 @@ export async function createSchedule(runtime: Runtime, caller: Caller, value: un
  */
 export async function updateSchedule(runtime: Runtime, caller: Caller, id: string, value: unknown): Promise<ScheduleView> {
 	const input = inputObject(value);
-	userOnlyCheck(input, caller);
 	const suppliedSubject = input.subject === undefined ? undefined : parseScheduleSubject(input.subject);
 	let saved!: ScheduleJoinRow;
 	let regenerate = false;
@@ -476,11 +470,14 @@ export async function updateSchedule(runtime: Runtime, caller: Caller, id: strin
 		const subject = suppliedSubject ?? (regenerate ? fallbackScheduleSubject(kind, payload) : existing.subject);
 		const source = suppliedSubject != null ? "manual" : regenerate ? "first-line" : existing.subject_source;
 		const next = timing ?? { cron: existing.cron, at: existing.at, timezone: existing.timezone, nextAt: existing.next_at };
-		const condition = conditions({
-			check: input.check === undefined ? existing.check_command : input.check,
-			checkCwd: input.checkCwd === undefined ? (input.check === null ? null : existing.check_cwd) : input.checkCwd,
-			stopAfterSuccess: input.stopAfterSuccess === undefined ? existing.stop_after_success === 1 : input.stopAfterSuccess,
-		}, next.cron);
+		const condition = conditions(
+			runtime,
+			caller,
+			input,
+			next.cron,
+			{ command: existing.check_command, cwd: existing.check_cwd, author: await checkAuthor(tx, scheduleScope(id)) },
+			existing.stop_after_success === 1,
+		);
 		await tx.run(
 			`UPDATE schedules SET revision = revision + 1, kind = ?, state = ?, cron = ?, at = ?, timezone = ?, payload = ?, next_at = ?, updated_at = ?, check_command = ?, check_cwd = ?, stop_after_success = ?, subject = ?, subject_source = ?
 			  WHERE id = ?`,
@@ -499,6 +496,7 @@ export async function updateSchedule(runtime: Runtime, caller: Caller, id: strin
 			source,
 			id,
 		);
+		await saveCheckAuthor(tx, scheduleScope(id), condition.author, now);
 		saved = await scheduleRow(tx, id);
 		return scheduleView(saved, runtime);
 	});
@@ -517,6 +515,7 @@ export async function deleteSchedule(runtime: Runtime, id: string): Promise<void
 		const row = await tx.get<ScheduleRow>("SELECT * FROM schedules WHERE id = ?", id);
 		if (!row || row.state === "deleted") return undefined;
 		await tx.run("UPDATE schedules SET state = 'deleted', next_at = NULL, updated_at = ? WHERE id = ?", now, id);
+		await saveCheckAuthor(tx, scheduleScope(id), null, now);
 		return row;
 	});
 	if (!deleted) throw ApiError.notFound(`schedule ${id}`);
@@ -574,6 +573,7 @@ export async function finishSchedule(runtime: Runtime, id: string, revision: num
 			id,
 			revision,
 		);
+		await saveCheckAuthor(tx, scheduleScope(id), null, now);
 	});
 	notifySchedulesChanged(runtime);
 }
diff --git a/pana/test/db.test.ts b/pana/test/db.test.ts
index b681c42fd..b316ba6ee 100644
--- a/pana/test/db.test.ts
+++ b/pana/test/db.test.ts
@@ -39,6 +39,8 @@ const PANA_TABLES = [
 	"objective_costs",
 	// Migration 14: the unread counter (REF-06).
 	"unread_counts",
+	// Migration 16: which session's box a check runs in (SCH-09).
+	"check_authors",
 ];
 
 const opened: TestPanad[] = [];
diff --git a/pana/test/objective-metrics.test.ts b/pana/test/objective-metrics.test.ts
index c6844c61d..d7a2bd0f7 100644
--- a/pana/test/objective-metrics.test.ts
+++ b/pana/test/objective-metrics.test.ts
@@ -1,7 +1,7 @@
 // WP18 metrics (OBJ-25..OBJ-29): declared metrics, append-only readings, derived baseline and
 // current value, the scheduler-run check, and the user-only target.
 
-import { existsSync, mkdtempSync, readdirSync, readFileSync } from "node:fs";
+import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, realpathSync } from "node:fs";
 import { tmpdir } from "node:os";
 import { join } from "node:path";
 import { afterEach, expect, it, vi } from "vitest";
@@ -268,29 +268,47 @@ it("OBJ-26 the check lives on the metric, runs on the clock with no session, and
 	expect(await counts()).toEqual(before);
 });
 
-it("OBJ-26 a check is the user's to define: a session may declare no check and change none", async () => {
+// OBJ-26/SCH-09: a session declares its own check again, and the check runs in the session's box.
+it("OBJ-26 a session's check runs in its own box, with its own env and cwd", async () => {
 	await start();
-	const { objective, lead } = await active();
-	const declared = await addMetric(objective.id, { name: "weight", unit: "kg", direction: "down" });
-
-	// A check runs on a timer inside panad, out of the declaring session's reach, so a session is
-	// refused on both paths: declaring a metric with one, and adding one to a metric.
-	const asLead = await t!.client.post(
-		`/objectives/${objective.id}/metrics`,
-		{ name: "sneaky", unit: "x", direction: "up", check: "env", checkEvery: "1h" },
-		{ caller: lead },
-	);
-	expect(asLead.status).toBe(403);
-	const setAsLead = await t!.client.post(`/objectives/${objective.id}/metrics/weight`, { check: "env", checkEvery: "1h" }, { caller: lead });
-	expect(setAsLead.status).toBe(403);
-	// Clearing one is a definition edit too, and gets the same refusal.
-	expect((await t!.client.post(`/objectives/${objective.id}/metrics/weight`, { check: null }, { caller: lead })).status).toBe(403);
-	expect((await metric(objective.id, "weight")).check).toBeNull();
-	expect(declared.check).toBeNull();
-
-	// A metric without a check is still a session's to declare, so the gate is the check alone.
-	const plain = await t!.client.post(`/objectives/${objective.id}/metrics`, { name: "steps", unit: "count", direction: "up" }, { caller: lead });
-	expect(plain.status).toBe(201);
+	process.env.PANA_TEST_SECRET = "panad-only";
+	try {
+		const { objective, lead } = await active();
+		const scratch = join(t!.runtime.paths.scratch, lead);
+		mkdirSync(scratch, { recursive: true });
+		// The command proves the box: the session's identity, its scratch, its PWD, and no variable
+		// panad holds. A miss prints the environment and fails with a non-numeric stdout.
+		// `PWD` is the physical path; `PANA_SCRATCH` keeps its own spelling (macOS symlinks /tmp).
+		const command = `[[ "$PANA_SESSION" == "${lead}" && "$PANA_SCRATCH" == "${scratch}" && "$(pwd -P)" == "${realpathSync(scratch)}" && -z "\${PANA_TEST_SECRET:-}" ]] && printf 80 || { env; exit 2; }`;
+		const declared = await addMetric(objective.id, { name: "weight", unit: "kg", direction: "down", check: command, checkEvery: "1d" }, lead);
+		// A session's check defaults to its scratch, never panad's cwd.
+		expect(declared.check).toMatchObject({ command, cwd: scratch });
+
+		await t!.clock.advanceTo(declared.check!.nextCheckAt!);
+		await vi.waitFor(async () => expect((await metric(objective.id, "weight")).readings).toHaveLength(1));
+		const checked = await metric(objective.id, "weight");
+		expect(checked.readings[0]).toMatchObject({ value: 80, source: "check" });
+		expect(checked.check!.lastCheck).toMatchObject({ status: "passed", exitCode: 0, stderr: "" });
+
+		// A cwd outside the box is refused while the check is declared, and the box is named.
+		const outside = await t!.client.post(
+			`/objectives/${objective.id}/metrics`,
+			{ name: "sneaky", unit: "x", direction: "up", check: "env", checkCwd: tmpdir(), checkEvery: "1h" },
+			{ caller: lead },
+		);
+		expect(outside.status).toBe(400);
+		expect((outside.body as { error: { code: string; message: string } }).error.code).toBe("invalid_check_cwd");
+		expect((outside.body as { error: { message: string } }).error.message).toContain(scratch);
+		// A peer session's worktree is outside it too.
+		const peer = await t!.client.post(
+			`/objectives/${objective.id}/metrics`,
+			{ name: "peer", unit: "x", direction: "up", check: "true", checkCwd: join(t!.runtime.paths.dir, "worktrees", "01ARZ3NDEKTSV4RRFFQ69G5FAV"), checkEvery: "1h" },
+			{ caller: lead },
+		);
+		expect(peer.status).toBe(400);
+	} finally {
+		delete process.env.PANA_TEST_SECRET;
+	}
 });
 
 it("OBJ-26 a non-numeric stdout, other exit code, signal, timeout, or error records failed and posts one notice", async () => {
@@ -691,8 +709,8 @@ it("OBJ-29 a reading records where it came from, and a session reports only its
 	expect((await t!.client.post(`/objectives/${objective.id}/metrics/weight/readings`, { value: "not a number" })).status).toBe(400);
 	expect((await t!.client.post(`/objectives/${objective.id}/metrics/weight/readings`, { value: 1, source: "oracle" })).status).toBe(400);
 
-	// Metrics arrived without a schema change of their own: migration 12 still holds them, and the
-	// last migration is a later, index-only one.
-	expect(MIGRATIONS.at(-1)).toMatchObject({ version: 15, name: "messages by sender" });
+	// Metrics arrived without a schema change of their own: migration 12 still holds them, and no
+	// later migration alters their shape (a check's author lives in `check_authors`, SCH-09).
 	expect(MIGRATIONS.find((migration) => migration.version === 12)).toMatchObject({ version: 12, name: "objectives" });
+	expect(MIGRATIONS.filter((migration) => migration.version > 12 && /objective_metrics/.test(migration.sql))).toEqual([]);
 });
diff --git a/pana/test/objectives.test.ts b/pana/test/objectives.test.ts
index 1384bfa45..69a8678b7 100644
--- a/pana/test/objectives.test.ts
+++ b/pana/test/objectives.test.ts
@@ -248,10 +248,9 @@ it("OBJ-02 one migration at the end of MIGRATIONS adds every table the package n
 		expect(await columns("objective_escalations"), column).toContain(column);
 	}
 
-	// It is the last migration, numbered, and the schema version follows it.
-	const last = MIGRATIONS.at(-1)!;
-	expect(last).toMatchObject({ version: 15, name: "messages by sender" });
-	expect(SCHEMA_VERSION).toBe(15);
+	// It is one migration, numbered, and the schema version follows the list.
+	expect(MIGRATIONS.find((migration) => migration.version === 12)).toMatchObject({ version: 12, name: "objectives" });
+	expect(SCHEMA_VERSION).toBe(MIGRATIONS.length);
 	expect(MIGRATIONS.map((migration) => migration.version)).toEqual(MIGRATIONS.map((_, index) => index + 1));
 
 	// A database newer than the code still refuses to open (DB-03 holds for this version).
diff --git a/pana/test/schedule-checks.test.ts b/pana/test/schedule-checks.test.ts
index 9817428b2..bb254d9e1 100644
--- a/pana/test/schedule-checks.test.ts
+++ b/pana/test/schedule-checks.test.ts
@@ -1,14 +1,47 @@
-import { mkdtempSync, rmSync, writeFileSync, existsSync, realpathSync, readFileSync } from "node:fs";
+import { execFileSync } from "node:child_process";
+import { mkdirSync, mkdtempSync, rmSync, writeFileSync, existsSync, realpathSync, readFileSync } from "node:fs";
 import { tmpdir } from "node:os";
 import { join } from "node:path";
 import { afterEach, describe, expect, it, vi } from "vitest";
 import { runCheck, CHECK_OUTPUT_BYTES, CHECK_TIMEOUT_MS } from "../src/schedules/check.ts";
+import { scheduleScope, sessionBox } from "../src/schedules/check-box.ts";
 import type { ScheduleView } from "../src/schedules/store.ts";
+import type { Runtime } from "../src/server/runtime.ts";
 import { createFakeClock, startTestPanad, type TestPanad } from "./harness/index.ts";
 
 let t: TestPanad | undefined;
 let dir: string | undefined;
-afterEach(async () => { await t?.close(); t = undefined; if (dir) rmSync(dir, { recursive: true, force: true }); dir = undefined; });
+afterEach(async () => {
+	await t?.close();
+	t = undefined;
+	if (dir) rmSync(dir, { recursive: true, force: true });
+	dir = undefined;
+	delete process.env.PANA_TEST_SECRET;
+});
+
+/** A session that exists (and can act as a caller) without running anything. */
+async function session(harness: TestPanad): Promise<string> {
+	const id = harness.runtime.newId();
+	await harness.runtime.db.write(async (tx) => {
+		await tx.run("INSERT INTO participants (id, kind, url, created_at) VALUES (?, 'session', ?, ?)", id, harness.runtime.url({ kind: "session", id }), harness.clock.now());
+		await tx.run("INSERT INTO sessions (id, state, depth, created_at, updated_at) VALUES (?, 'idle', 0, ?, ?)", id, harness.clock.now(), harness.clock.now());
+	});
+	return id;
+}
+
+/** A runtime with only the paths a session's box reads, for unit tests of the runner. */
+function pathsOnly(state: string): Runtime {
+	return { paths: { dir: state, scratch: join(state, "scratch"), memoryWorktrees: join(state, "memory", "worktrees") } } as unknown as Runtime;
+}
+
+function canNamespace(): boolean {
+	try {
+		execFileSync("unshare", ["--map-root-user", "--mount", "true"], { stdio: "ignore" });
+		return true;
+	} catch {
+		return false;
+	}
+}
 const cron = "* * * * *";
 const base = { kind: "session", cron, payload: { prompt: "only when ready" } };
 async function create(extra: Record<string, unknown> = {}) {
@@ -88,26 +121,125 @@ describe("schedule conditions", () => {
 		expect((await show(schedule.id)).state).toBe("active");
 	});
 
-	it("SCH-09 a check is the user's to define: a session's create and update are both refused", async () => {
+	// SCH-09: a session defines its own check again, and the check runs inside that session's box.
+	it("SCH-09 a session defines a check that runs in its own box, with its own env and cwd", async () => {
+		let calls = 0;
+		t = await startTestPanad({ handlers: { "sessions.create": () => { calls++; return { status: 201 }; } } });
+		process.env.PANA_TEST_SECRET = "panad-only";
+		const mine = await session(t);
+		const scratch = join(t.runtime.paths.scratch, mine);
+		mkdirSync(scratch, { recursive: true });
+		const asSession = (extra: Record<string, unknown>) => t!.client.post<{ schedule: ScheduleView }>("/schedules", { ...base, ...extra }, { caller: mine });
+
+		// The command proves the box: the session's own identity, its scratch, its PWD, and no
+		// variable panad holds. Any miss prints the environment and fails with exit 2.
+		// `PWD` is the physical path the kernel starts the child in; on macOS `/tmp` and `/var` are
+		// symlinks, so compare it with the resolved scratch while `PANA_SCRATCH` keeps its own spelling.
+		const command = `[[ "$PANA_SESSION" == "${mine}" && "$PANA_SCRATCH" == "${scratch}" && "$(pwd -P)" == "${realpathSync(scratch)}" && -z "\${PANA_TEST_SECRET:-}" ]] || { env; exit 2; }`;
+		const made = await asSession({ check: command });
+		expect(made.status).toBe(201);
+		const schedule = made.body.schedule;
+		// A session's check defaults to its scratch, never panad's cwd.
+		expect(schedule).toMatchObject({ check: command, checkCwd: scratch });
+		expect(await t.runtime.db.get("SELECT session_id FROM check_authors WHERE scope = ?", scheduleScope(schedule.id))).toEqual({ session_id: mine });
+
+		await t.clock.advanceTo(schedule.nextAt!);
+		expect(await checked(schedule.id)).toMatchObject({ status: "passed", exitCode: 0, stderr: "" });
+		await vi.waitFor(() => expect(calls).toBe(1));
+
+		// An edit that leaves the cwd alone keeps it; a cwd outside the box is refused, and names it.
+		const kept = await t.client.post<{ schedule: ScheduleView }>(`/schedules/${schedule.id}`, { check: "exit 0" }, { caller: mine });
+		expect(kept.status).toBe(200);
+		expect(kept.body.schedule.checkCwd).toBe(scratch);
+		// An edit that does not name the check keeps its command, cwd, and author.
+		expect((await t.client.post(`/schedules/${schedule.id}`, { payload: { prompt: "edited" } }, { caller: mine })).status).toBe(200);
+		expect(await show(schedule.id)).toMatchObject({ check: "exit 0", checkCwd: scratch });
+		expect(await t.runtime.db.get("SELECT session_id FROM check_authors WHERE scope = ?", scheduleScope(schedule.id))).toEqual({ session_id: mine });
+		const outside = await t.client.post(`/schedules/${schedule.id}`, { checkCwd: tmpdir() }, { caller: mine });
+		expect(outside.status).toBe(400);
+		expect((outside.body as { error: { code: string; message: string } }).error).toMatchObject({ code: "invalid_check_cwd" });
+		expect((outside.body as { error: { message: string } }).error.message).toContain(scratch);
+		// A peer session's worktree is outside it too.
+		const peer = join(t.runtime.paths.dir, "worktrees", "01ARZ3NDEKTSV4RRFFQ69G5FAV");
+		expect((await t.client.post(`/schedules/${schedule.id}`, { checkCwd: peer }, { caller: mine })).status).toBe(400);
+		// Clearing the check clears its author with it.
+		expect((await t.client.post(`/schedules/${schedule.id}`, { check: null }, { caller: mine })).status).toBe(200);
+		expect(await show(schedule.id)).toMatchObject({ check: null, checkCwd: null });
+		expect(await t.runtime.db.get("SELECT session_id FROM check_authors WHERE scope = ?", scheduleScope(schedule.id))).toBeFalsy();
+	});
+
+	// SCH-09/#203: the box is the author's, never the schedule creator's. #203's ownership gate is
+	// PR #257 and is not in master yet; this holds either way, because the author is the caller.
+	it("SCH-09 a session's check runs in the caller's box, not the schedule creator's", async () => {
 		t = await startTestPanad();
-		const session = t.runtime.newId();
-		const now = t.clock.now();
-		await t.runtime.db.write(async (tx) => {
-			await tx.run("INSERT INTO participants (id, kind, url, created_at) VALUES (?, 'session', ?, ?)", session, t!.runtime.url({ kind: "session", id: session }), now);
-			await tx.run("INSERT INTO sessions (id, state, depth, created_at, updated_at) VALUES (?, 'idle', 0, ?, ?)", session, now, now);
-		});
-		const asSession = (extra: Record<string, unknown>) => t!.client.post("/schedules", { ...base, ...extra }, { caller: session });
+		const other = await session(t);
+		const mine = await session(t);
+		const theirs = await t.client.post<{ schedule: ScheduleView }>("/schedules", { ...base }, { caller: other });
+		expect(theirs.status).toBe(201);
+		const edited = await t.client.post<{ schedule: ScheduleView }>(
+			`/schedules/${theirs.body.schedule.id}`,
+			{ check: 'printf "%s:%s" "${PANA_SESSION}" "${PANA_SCRATCH}"' },
+			{ caller: mine },
+		);
+		expect(edited.status).toBe(200);
+		expect(await t.runtime.db.get("SELECT session_id FROM check_authors WHERE scope = ?", scheduleScope(theirs.body.schedule.id))).toEqual({ session_id: mine });
+		await t.clock.advanceTo(theirs.body.schedule.nextAt!);
+		await vi.waitFor(async () => expect((await show(theirs.body.schedule.id)).lastCheck).not.toBeNull());
+		// The creator's id never reaches the check: it runs as the caller that wrote the check.
+		expect((await show(theirs.body.schedule.id)).lastCheck!.stdout).toBe(`${mine}:${join(t.runtime.paths.scratch, mine)}`);
+	});
+
+	// SCH-09/GUARD: a session's check cannot leave its box even when the stored row says it should,
+	// and the guard refuses the user's primary checkout either way.
+	it("SCH-09 a session check is refused outside its box, and the guard keeps it out of a checkout", async () => {
+		const home = mkdtempSync(join(tmpdir(), "pana-box-home-"));
+		const state = mkdtempSync(join(tmpdir(), "pana-box-state-"));
+		dir = home;
+		try {
+			const repo = join(home, "dotfiles");
+			mkdirSync(join(repo, ".git"), { recursive: true });
+			const box = sessionBox(pathsOnly(state), "01M6YZ5VCHZEZ6HKNF1KXFG08C");
+			mkdirSync(box.scratchDir, { recursive: true });
+			const clock = createFakeClock();
+			const host = { stateDir: state, box, checkoutRoots: [home] };
+
+			// A stored cwd inside the user's checkout is a failure, not a run.
+			const outside = await runCheck(`printf nope > ${join(repo, "from-check.txt")}`, repo, clock, new AbortController().signal, host);
+			expect(outside).toMatchObject({ status: "failed", exitCode: null });
+			expect(outside.error).toContain("box");
+			expect(existsSync(join(repo, "from-check.txt"))).toBe(false);
 
-		expect((await asSession({ check: "touch planted" })).status).toBe(403);
-		expect((await asSession({ checkCwd: tmpdir() })).status).toBe(403);
-		// A session may still schedule its own work and change it; only the check is the user's.
-		const own = await asSession({ payload: { prompt: "my own work" } });
-		expect(own.status).toBe(201);
-		const id = (own.body as { schedule: ScheduleView }).schedule.id;
-		expect((await t.client.post(`/schedules/${id}`, { check: "touch planted" }, { caller: session })).status).toBe(403);
-		expect((await t.client.post(`/schedules/${id}`, { check: null }, { caller: session })).status).toBe(403);
-		expect((await t.client.post(`/schedules/${id}`, { payload: { prompt: "edited" } }, { caller: session })).status).toBe(200);
-		expect((await show(id)).check).toBeNull();
+			// The same command runs inside the box.
+			const inside = await runCheck(`printf ok > ${join(box.scratchDir, "done.txt")}; printf ok`, box.scratchDir, clock, new AbortController().signal, host);
+			expect(inside).toMatchObject({ status: "passed", stdout: "ok" });
+			expect(readFileSync(join(box.scratchDir, "done.txt"), "utf8")).toBe("ok");
+		} finally {
+			rmSync(state, { recursive: true, force: true });
+		}
+	});
+
+	it.skipIf(!canNamespace())("SCH-09/GUARD-02 sandbox mode mounts the user's checkout read-only for a session check", async () => {
+		const home = mkdtempSync(join(tmpdir(), "pana-box-home-"));
+		const state = mkdtempSync(join(tmpdir(), "pana-box-state-"));
+		dir = home;
+		try {
+			const repo = join(home, "dotfiles");
+			mkdirSync(join(repo, ".git"), { recursive: true });
+			const box = sessionBox(pathsOnly(state), "01M6YZ5VCHZEZ6HKNF1KXFG08C");
+			mkdirSync(box.scratchDir, { recursive: true });
+			const result = await runCheck(
+				`printf nope > ${join(repo, "from-check.txt")}`,
+				box.scratchDir,
+				createFakeClock(),
+				new AbortController().signal,
+				{ stateDir: state, box, checkoutRoots: [home], protectCheckouts: "sandbox" },
+			);
+			// Bash reports the read-only mount as a failed write; the file never appears.
+			expect(result.exitCode).not.toBe(0);
+			expect(existsSync(join(repo, "from-check.txt"))).toBe(false);
+		} finally {
+			rmSync(state, { recursive: true, force: true });
+		}
 	});
 
 	it("SCH-12 a check sees only PANA_ENV_NAMES, never panad's own environment", async () => {

```

## @joshbeckman committed a change on Monday (2026-11-09) at 01:48:02

feat(pana): a session may define a check, and it runs in that session…

…'s box

#201/#256 hardened check execution and, in the same change, made `check`/`checkCwd`
the user's alone. The hardening stays; the ban goes. A check is defined once and then
runs on panad's own clock, so what mattered was never who wrote it but where it runs:
in the box of the session that wrote it, exactly like that session's `bash` call.

- `src/schedules/check-box.ts` is the one place the rule lives. `sessionBox` names the
  session's roots (scratch, its state worktrees, its memory worktree, and every adapter
  tree its ownership receipt names); `planCheck` decides the check a write ends up with
  (the user keeps any absolute cwd, a session is confined to its box and defaults to its
  scratch, and an edit that does not name the check keeps its command, cwd, and author);
  `boxRefusal` is the same rule for a stored row, which authoring turns into a 400 and
  running turns into a failed check.
- `runCheck` builds its `PanaExecutionEnv` with the authoring session's id and scratch, so
  the child sees `PANA_SESSION`/`PANA_SCRATCH`, the checkout guard and any sandbox mounts
  treat the check as that session's command, and a cwd outside the box is refused before
  anything spawns. The allowlisted environment, the 30-second timeout, the 8 KiB per
  stream, and the killed process group are unchanged. The user's check still gets no
  session identity and runs at its recorded cwd.
- The author is stored beside the check in `check_authors`, keyed `schedule:<id>` or
  `metric:<objective>/<name>`; a separate table because `ALTER TABLE ... ADD COLUMN` cannot
  be written idempotently in SQLite and DB-03 requires every migration to re-run. Rows are
  deleted with the schedule and with a spent wake.
- `store.ts` and `objectives/metrics.ts` drop the 403 and record the author; the scheduler
  and the metric-check loop read it and run through `runStoredCheck`.

Tests prove a session check (a) runs with the session's environment and no panad variable
(including a planted `PANA_TEST_SECRET`), (b) cannot name a cwd outside its box, on create
or update, (c) cannot run in or write the user's checkout (guard refuses the cwd; sandbox
mounts it read-only), (d) the user's check still runs at a user-chosen cwd, and (e) the box
is the author's even when another session's schedule is edited, so a check can never run
under the schedule creator's identity.

Closes #279

## @joshbeckman committed a change on Monday (2026-11-09) at 01:48:04

docs(pana): spec a session's check as a decision, and say where its c…

…wd comes from

SCH-09, SCH-12, OBJ-26, and GUARD-06 stated the user-only rule as a summary of the
code. They now state the decision: a check belongs to the schedule or the metric, so
whoever may change that thing may set or clear its check; a session's check runs in
that session's own box with its own environment, guard, and roots, and the user's check
keeps the user's cwd. The CLI help no longer says "user only" and says what the default
cwd is for each kind of caller.

## @joshbeckman committed a change on Monday (2026-11-09) at 02:01:00

test(pana): compare a check's cwd physically, so macOS symlinks do no…

…t fail it

macOS resolves /tmp and /var through symlinks, so a check spawned in a scratch
directory sees a physical $PWD that differs from the PANA_SCRATCH string pana
exports. The box is still the same directory; the assertion compared the two
spellings. Compare $PWD with the resolved scratch instead.

## @joshbeckman [commented on Monday (2026-11-09) at 02:01:05](https://github.com/joshbeckman/dotfiles/pull/280#issuecomment-6730454776)

CI: the macOS job failed on the new box test, not on the change: a session's scratch under `/tmp` is `/private/tmp` physically, so the check's `$PWD` did not match the `PANA_SCRATCH` string pana exports. The assertion now compares `$(pwd -P)` with the resolved scratch, and still compares `PANA_SCRATCH` verbatim. Pushed c9a7257; local run of both files: 30 passed.

### ✅ @joshbeckman merged this on Monday (2026-11-09) at 02:04:17

### 🔒 @joshbeckman closed this on Monday (2026-11-09) at 02:04:17

### 🔗 @joshbeckman mentioned this in [#282: test(pana): a session sets a check only on its own schedule](https://github.com/joshbeckman/dotfiles/pull/282) on Monday (2026-11-09) at 02:19:09



## Merged on Monday (2026-11-09) at 02:04:17
