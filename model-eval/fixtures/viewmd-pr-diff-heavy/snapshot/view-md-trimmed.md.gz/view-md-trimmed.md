# Pull Request #280: [fix(pana): a session may define a check, and it runs in that session's box](https://github.com/joshbeckman/dotfiles/pull/280) opened by @joshbeckman on Monday (2026-11-09) at 01:49:39

## The 403 being removed

A session that owns a PR wants a five-minute poll that only wakes it when something changed:

```
$ pana schedule wake --cron "*/5 * * * *" --check ./changed.sh --note "check PR 300"
forbidden: only the user may set a check on a schedule
```

The same refusal hit a metric:

```
only the user may define a check on a metric
```

#201/#256 was right to take panad's environment away from a check: it runs on panad's clock with
panad's identity, so it must not see `process.env` (provider keys) or start in panad's cwd. But it
also made `check`/`checkCwd` the user's alone, and that removed the legitimate case above. The
definition is not the risk; the run is. So a session may define a check again, and the check runs
where that session's `bash` runs.

## The confinement a session check now gets

- **Same environment as its `bash`.** `runCheck` builds `PanaExecutionEnv` with the authoring
  session's id and scratch, so the child sees exactly `PANA_ENV_NAMES` (`PATH`, `HOME`, `USER`,
  `LANG`, `TERM`, `PANA_SESSION`, `PANA_THREAD`, `PANA_STATE`, `PANA_SCRATCH`,
  `PANA_BROWSER_SESSION`) and never panad's `process.env`.
- **Same guard.** The checkout guard and any `tools.protectCheckouts: "sandbox"` mounts treat the
  check as that session's command: it cannot use a cwd in a checkout it does not own, and in
  sandbox mode an unowned checkout is mounted read-only for it.
- **Its own box as cwd.** `sessionBox` names the roots: the session's scratch, its state
  worktrees, its memory worktree, and every adapter tree its ownership receipt names. A cwd
  outside them is 400 `invalid_check_cwd` naming the box while the check is defined, and a
  `failed` result rather than a run if a stored row ever names one. The default is the session's
  scratch, never panad's cwd.
- **The author's box, not the schedule creator's.** The author is stored beside the check
  (`check_authors`), so a check can never run under another session's identity.
- **Unchanged limits.** The 30-second timeout on the runtime clock, 8 KiB retained per stream, and
  the killed process group. The user's own check keeps the user's cwd and no session identity.

## Before and after

| as a session | before | after |
| --- | --- | --- |
| `POST /schedules {check}` | 403 `only the user may set a check on a schedule` | 201, `checkCwd` = the session's scratch |
| `POST /schedules/:id {check, checkCwd: "/tmp"}` | 403 | 400 `invalid_check_cwd` naming the session's box |
| `POST /schedules/:id {check}` on a peer's schedule | 403 | 200, and the check runs as **the caller**, not the peer |
| `POST /objectives/:id/metrics {check}` | 403 `only the user may define a check on a metric` | 201, runs in the session's box |
| `POST /schedules {check, checkCwd: "/home/josh/dotfiles"}` (user) | 201 | 201 (unchanged) |
| a session check whose stored cwd is the user's checkout | n/a | `failed` before spawn: "outside session …'s box" |
| the same, `protectCheckouts: "sandbox"` and a cwd in its own scratch | n/a | the write to the checkout fails on a read-only mount |

Tests, all in `test/schedule-checks.test.ts` and `test/objective-metrics.test.ts`:

- **no provider keys**: the check asserts `PANA_SESSION`, `PANA_SCRATCH`, `PWD`, and an empty
  planted `PANA_TEST_SECRET`, then prints its reading; any miss dumps `env` and exits non-zero.
- **cwd outside the box**: `/tmp` and a peer session's worktree are both 400 on create and update;
  changing only the command keeps the stored box cwd; an unrelated edit keeps cwd and author.
- **the user's checkout**: refused as a cwd before anything spawns, and in sandbox mode a write
  from the session's own scratch into a checkout exits non-zero and the file never appears.
- **the user's check**: still created with `checkCwd: process.cwd()` or a chosen directory and
  still dispatches.
- **who owns the box**: a session editing another session's schedule (which master still allows;
  #203 is PR #257, not merged) gets a check that runs with *its* `PANA_SESSION`, never the
  creator's.

## Deliberately left out

- **#203's ownership gate.** `origin/master` has no ownership check on `updateSchedule` (PR #257
  is open, and rebases this file). This change does not add one; it only guarantees that a check
  is authored by the caller, so the two changes compose. Expect a small conflict in
  `src/schedules/store.ts` whichever lands second.
- **Recreating a swept box.** A check whose session's scratch was swept fails with "the session's
  box may have been removed" rather than recreating the directory; a check must not fight the
  scratch sweep.
- **A session's explicit-cwd escape hatch (GUARD-05).** A session created inside the user's
  checkout may write there, but a check it defines may not: the box is scratch, worktrees, and
  memory only. A cron run has no user watching it.

## Checks

- `npx tsc --noEmit` clean.
- `npx vitest run` — 58 files, 709 passed, 2 skipped.
- `npx vitest run test/schedule-checks.test.ts test/objective-metrics.test.ts` — 30 passed.

Closes #279

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M6YZ5VCMYCF05QAMNBE7SYTA <josh@joshbeckman.org>


## Stats: 478 lines added, 125 lines deleted, 14 files changed

```text
pana/SPEC.md
pana/src/cli/commands.ts
pana/src/db/schema.ts
pana/src/objectives/cli.ts
pana/src/objectives/metric-checks.ts
pana/src/objectives/metrics.ts
pana/src/schedules/check-box.ts
pana/src/schedules/check.ts
pana/src/schedules/scheduler.ts
pana/src/schedules/store.ts
pana/test/db.test.ts
pana/test/objective-metrics.test.ts
pana/test/objectives.test.ts
pana/test/schedule-checks.test.ts

```

## @joshbeckman committed a change on Monday (2026-11-09) at 01:48:02

feat(pana): a session may define a check, and it runs in that session…

…'s box

#201/#256 hardened check execution and, in the same change, made `check`/`checkCwd`
the user's alone. The hardening stays; the ban goes. A check is defined once and then
runs on panad's own clock, so what mattered was never who wrote it but where it runs:
in the box of the session that wrote it, exactly like that session's `bash` call.

- `src/schedules/check-box.ts` is the one place the rule lives. `sessionBox` names the
  session's roots (scratch, its state worktrees, its memory worktree, and every adapter
  tree its ownership receipt names); `planCheck` decides the check a write ends up with
  (the user keeps any absolute cwd, a session is confined to its box and defaults to its
  scratch, and an edit that does not name the check keeps its command, cwd, and author);
  `boxRefusal` is the same rule for a stored row, which authoring turns into a 400 and
  running turns into a failed check.
- `runCheck` builds its `PanaExecutionEnv` with the authoring session's id and scratch, so
  the child sees `PANA_SESSION`/`PANA_SCRATCH`, the checkout guard and any sandbox mounts
  treat the check as that session's command, and a cwd outside the box is refused before
  anything spawns. The allowlisted environment, the 30-second timeout, the 8 KiB per
  stream, and the killed process group are unchanged. The user's check still gets no
  session identity and runs at its recorded cwd.
- The author is stored beside the check in `check_authors`, keyed `schedule:<id>` or
  `metric:<objective>/<name>`; a separate table because `ALTER TABLE ... ADD COLUMN` cannot
  be written idempotently in SQLite and DB-03 requires every migration to re-run. Rows are
  deleted with the schedule and with a spent wake.
- `store.ts` and `objectives/metrics.ts` drop the 403 and record the author; the scheduler
  and the metric-check loop read it and run through `runStoredCheck`.

Tests prove a session check (a) runs with the session's environment and no panad variable
(including a planted `PANA_TEST_SECRET`), (b) cannot name a cwd outside its box, on create
or update, (c) cannot run in or write the user's checkout (guard refuses the cwd; sandbox
mounts it read-only), (d) the user's check still runs at a user-chosen cwd, and (e) the box
is the author's even when another session's schedule is edited, so a check can never run
under the schedule creator's identity.

Closes #279

## @joshbeckman committed a change on Monday (2026-11-09) at 01:48:04

docs(pana): spec a session's check as a decision, and say where its c…

…wd comes from

SCH-09, SCH-12, OBJ-26, and GUARD-06 stated the user-only rule as a summary of the
code. They now state the decision: a check belongs to the schedule or the metric, so
whoever may change that thing may set or clear its check; a session's check runs in
that session's own box with its own environment, guard, and roots, and the user's check
keeps the user's cwd. The CLI help no longer says "user only" and says what the default
cwd is for each kind of caller.

## @joshbeckman committed a change on Monday (2026-11-09) at 02:01:00

test(pana): compare a check's cwd physically, so macOS symlinks do no…

…t fail it

macOS resolves /tmp and /var through symlinks, so a check spawned in a scratch
directory sees a physical $PWD that differs from the PANA_SCRATCH string pana
exports. The box is still the same directory; the assertion compared the two
spellings. Compare $PWD with the resolved scratch instead.

## @joshbeckman [commented on Monday (2026-11-09) at 02:01:05](https://github.com/joshbeckman/dotfiles/pull/280#issuecomment-6730454776)

CI: the macOS job failed on the new box test, not on the change: a session's scratch under `/tmp` is `/private/tmp` physically, so the check's `$PWD` did not match the `PANA_SCRATCH` string pana exports. The assertion now compares `$(pwd -P)` with the resolved scratch, and still compares `PANA_SCRATCH` verbatim. Pushed c9a7257; local run of both files: 30 passed.

### ✅ @joshbeckman merged this on Monday (2026-11-09) at 02:04:17

### 🔒 @joshbeckman closed this on Monday (2026-11-09) at 02:04:17

### 🔗 @joshbeckman mentioned this in [#282: test(pana): a session sets a check only on its own schedule](https://github.com/joshbeckman/dotfiles/pull/282) on Monday (2026-11-09) at 02:19:09



## Merged on Monday (2026-11-09) at 02:04:17
