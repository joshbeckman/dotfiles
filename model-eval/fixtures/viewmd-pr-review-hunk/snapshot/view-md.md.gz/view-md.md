# Pull Request #272: [docs(pana): tell sessions how to find threads and ask to join one](https://github.com/joshbeckman/dotfiles/pull/272) opened by @joshbeckman on Sunday (2026-11-08) at 22:23:53

## What

Documentation only: no route, no command, no schema, no behaviour changes. #268 (a `thread join` command) is closed; the gap was never a missing verb, it was that sessions were never told what already exists.

Nothing in `pana/prompt.md` mentioned `pana thread search`, `pana thread list`, or that any same-domain thread can be read by its URL, so a session had no documented way to look outward — and no documented way in, because its own reply to a thread it is not a participant of is refused (THR-09). The only existing path is a participant's `--cc`, which appeared in `README.md` as one clause and in the prompt not at all.

So the Threads section now says:

- how to find threads it is not in (`pana thread search`, `pana thread list`, `pana_thread_read` by URL or ID), and that reading never joins a thread or touches another participant's mail;
- that a reply from a non-participant is refused, and that the way in is to **ask a participant** — reply in a thread they share, or in their own thread addressed to the user, naming the thread and what they would add;
- the exact mechanism the participant uses, `pana thread respond --thread T --after M --body B --cc <your session URL>`, that membership is forward-only, that the refused reply must not be used as the request, and that reading and citing is usually enough because a join tells everyone and wakes every session there.

`README.md`'s Threads section gains a matching **Joining a thread** subsection for the user: the same procedure, that the added session participates from that message on and never sees the history, that `--cc` takes a session ULID, `pana://` URL, or the user, that it returns 404 for an unknown session and 409 for an archived one (a thread holding an archived session accepts no deliveries, STA-07), and that there is no way to leave a thread or remove a participant.

## Spec

New `PRM-09`, checked off in `pana/SPEC.md`: the rendered prompt tells a session how to find and read threads it is not in, that reading never joins, and that entry is a participant's `--cc` asked for out of band, plus the instructions not to use the refused reply as the request, to read before joining because membership is forward-only, and to join only when the thread needs what the session knows.

## Proof

`npx tsc --noEmit` clean; `npm test` 687 passed, 2 skipped.

`PRM-09` in `pana/test/extension.test.ts` renders the prompt for a real session and asserts the guidance is there: `pana thread search`, `pana thread list`, `pana_thread_read`, "Reading never joins", the refusal, `--cc`, "never what came before", and "Do not send the refused reply as a way of asking".

No web changes, so no screenshots.

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M6MD5XX2TBGA9ZFHE9QMSDGY


## Stats: 54 lines added, 0 lines deleted, 4 files changed

```diff
diff --git a/pana/README.md b/pana/README.md
index ef5cc7a58..16154b012 100644
--- a/pana/README.md
+++ b/pana/README.md
@@ -357,6 +357,19 @@ The `default` profile applies when `--profile` is absent. With no `--cwd` and no
   ```
 - Files are stored on disk under `files/<ulid>/<name>`. The database stores the path, size, media type, and uploader. The type is read from the bytes, never from the upload: a raster image previews inline, and everything else is served as a download, so no attachment can run as a page on pana's own origin. Message Markdown references a file by its `pana://` URL, and the PWA rewrites it to an HTTP URL served by `panad`. `--attach` on the CLI and the PWA's Attach button, drop, or pasted screenshot all upload through `POST /files` and append the same reference. An inline image is requested as `?w=1024`: the host's resizer (`sips` on macOS, ImageMagick elsewhere) makes that copy once, keeps it in `files/<ulid>/.resized/`, and the link opens the original. With no resizer installed, the original is served.
 
+### Joining a thread
+
+Only participants may respond, and a session cannot add itself: its reply is refused with 403. The way in is a participant's `--cc` on a message it sends to that thread.
+
+```sh
+# run by a participant of the target thread
+pana thread respond --thread TARGET --after NEWEST --body "adding the session that has the CI history" --cc 01SESSION…
+```
+
+The added session participates from that message on: it receives that message and every later one, never the earlier ones, and its `joined_message_id` records where it joined. A session that wants in therefore asks out of band — replying in a thread it shares with a participant, or starting a thread with one (`pana thread create --to`), naming the thread it wants to join and what it would add. You are a participant in most threads and may add a session the same way, but no one is the moderator: any participant can. `pana/prompt.md` tells sessions that, so the request arrives as an ordinary message instead of as a rejected reply.
+
+`--cc` takes a session ULID or `pana://` URL, or the user. It returns 404 for a session that does not exist and 409 for an archived one, because a thread holding an archived session accepts no deliveries at all (STA-07). There is no command to leave a thread or to remove a participant.
+
 ### Commands
 
 ```sh
diff --git a/pana/SPEC.md b/pana/SPEC.md
index e3ae6a1ac..ede0bbd38 100644
--- a/pana/SPEC.md
+++ b/pana/SPEC.md
@@ -263,6 +263,7 @@ The API is HTTP with JSON bodies. `panad` serves the same routes on two listener
 - [x] **PRM-06** The rendered prompt directs sessions at the start of each run to the optional root `AGENTS.md` and relevant workflow files in published memory (`main`), not stale worktree copies. It skips absent entrypoints without unsolicited setup, loads only relevant pointers, subordinates domain guidance to higher-priority instructions, grants no additional permissions, and preserves the ordinary memory publishing rules.
 - [x] **PRM-07** The rendered prompt supplies general memory hygiene without requiring a domain entrypoint: preserve judgment rather than task history; require concrete future utility beyond ordinary retrieval/canonical sources; route canonical knowledge, search relevant history, keep minimal scoped/sourced explanations, avoid overgeneralizing local decisions, prune completed ledgers/duplicates, and separate active checkpoints. Domain memory supplies local choices; memory grants no new authority. This is a prompt contract, not automated content enforcement.
 - [x] **PRM-08** The rendered prompt requires completion-time cleanup of session-created worktrees after preservation and task/PR completion, with standing authority limited to those trees. It requires ownership and loss-prevention checks, supported removal tools, no force/unlock/branch deletion/receipt edits or refusal bypass, and reporting paths/reasons for retained trees. Project trees and receipts have no daemon TTL sweep; user/peer/cwd-only trees and bulk cleanup are not authorized.
+- [x] **PRM-09** The rendered prompt tells a session how to find and read threads it is not a participant of (`pana thread search`, `pana thread list`, and `pana thread read` by URL or ID), that reading never joins the thread or touches another participant's mail, and that entry is another participant's `--cc`, which the session asks for out of band from a participant — in a thread they share, or by starting a thread with one — because its own reply is refused and no participant is a moderator. It says not to use the refused reply as the request, to read what it needs before joining because membership is forward-only, and to join only when the thread needs what the session knows.
 
 ### Tools
 
diff --git a/pana/prompt.md b/pana/prompt.md
index 3e81b51df..b09647d97 100644
--- a/pana/prompt.md
+++ b/pana/prompt.md
@@ -29,6 +29,19 @@ pana refuses a `bash` command that sleeps for {{max_sleep}} seconds or more.
 A thread is an append-only list of messages between participants. Every message goes to
 every participant.
 
+`pana thread search --query TEXT` and `pana thread list` find threads you are not in, and
+`pana thread read` opens any thread or message by URL or ID. Reading never joins a thread and
+never touches anyone else's mail.
+
+Replying to a thread you are not a participant of is refused. To get in, ask a participant:
+reply in a thread you share with one, or start a thread with one (`pana thread create --to
+ADDRS`), naming the thread and saying what you would add. A participant then adds you with
+`--cc` on their next message (`pana thread respond --thread T --after M --body B --cc <your
+session URL>`), and you receive that message and everything after it, never what came before,
+so read what you need first. Do not send the refused reply as a way of asking: it fails and
+reaches nobody. Reading and citing what you found is usually enough; join a thread when it
+needs what you know, because every participant is told and every session there is woken.
+
 When a user's message starts your run, or the prompt that created you does, your final
 message is posted to that thread for you. Do not repeat it with a tool. An empty final
 message posts nothing.
diff --git a/pana/test/extension.test.ts b/pana/test/extension.test.ts
index 9683a278f..8105f1814 100644
--- a/pana/test/extension.test.ts
+++ b/pana/test/extension.test.ts
@@ -840,6 +840,33 @@ describe("system prompt", () => {
 		expect(project).not.toContain("PARENT_AGENTS_PRM02");
 	});
 
+	it("PRM-09 the prompt tells a session how to find threads it is not in and how to ask to join one", async () => {
+		const seeded = await start();
+		const first = seeded.sessions[0]!;
+		const conversation = await conversationOf(t!, first.conversationId);
+		await conversation.configure({ model: FAUX_MODEL, cwd: tempDir("pana-cwd-") }, ctx);
+		await runTurn();
+
+		const pana = promptSections(await contextOf(t!, first.conversationId)).get("pana")!;
+		// Discovery: the commands that find a thread the session is not a participant of.
+		expect(pana).toContain("pana thread search");
+		expect(pana).toContain("pana thread list");
+		// CLI spelling throughout this paragraph: pana_thread_read is the tool name, which the
+		// tool list below the paragraph carries, and mixing the two reads as a different thing.
+		expect(pana).toContain("pana thread read");
+		// Reading is not joining, and the session cannot add itself.
+		expect(pana).toContain("Reading never joins");
+		expect(pana).toContain("refused");
+		// The way in: a participant's --cc, asked of a participant out of band, forward-only.
+		expect(pana).toContain("ask a participant");
+		expect(pana).toContain("start a thread with one");
+		expect(pana).toContain("--cc");
+		expect(pana).toContain("never what came before");
+		expect(pana).toContain("Do not send the refused reply as a way of asking");
+		// The discovery sentence names the commands and stops there; --help carries the output shape.
+		expect(pana).not.toContain("newest-created first");
+	});
+
 	it("PRM-03 the pana section includes the session URL, the memory worktree, and the memory commands", async () => {
 		const seeded = await start();
 		const first = seeded.sessions[0]!;

```

## @ committed a change on Sunday (2026-11-08) at 22:23:42

docs(pana): tell sessions how to find threads and ask to join one (PR…

…M-09)

Nothing in pana/prompt.md mentioned pana thread search, pana thread list,
or that any same-domain thread can be read by URL, so a session had no
documented way to look outward — and no documented way in, since its
reply to a thread it is not a participant of is refused (THR-09).

Document the existing mechanics instead of changing them: how to find and
read threads, that reading never joins, and that entry is a participant's
--cc, which a session asks for out of band because it cannot add itself.
README.md gains the same procedure for the user, including the 404/409
answers --cc gives and the fact that there is no way to leave.

Adds PRM-09 to SPEC.md with a test that renders the prompt and asserts
the guidance is present.

## Review thread on `pana/prompt.md`

```diff
@@ -29,6 +29,20 @@ pana refuses a `bash` command that sleeps for {{max_sleep}} seconds or more.
 A thread is an append-only list of messages between participants. Every message goes to
 every participant.
 
+You can find threads you are not in: `pana thread search --query TEXT` searches the subject
+and messages of every same-domain thread, `pana thread list` lists them newest-created first
+with their `pana://` URLs, and `pana_thread_read` reads any thread or message by URL or ID.
+Reading never joins a thread and never touches anyone else's mail.
+
+Replying to a thread you are not a participant of is refused. To get in, ask a participant:
+reply in a thread you are both in, or in a thread of your own addressed to the user, naming
```
## @joshbeckman [commented on Monday (2026-11-09) at 00:20:04](https://github.com/joshbeckman/dotfiles/pull/272#discussion_r4508428836)

Not to the user, but to a thread participant, right? The user doesn't have to be the moderator

## Review thread on `pana/prompt.md`

```diff
@@ -29,6 +29,20 @@ pana refuses a `bash` command that sleeps for {{max_sleep}} seconds or more.
 A thread is an append-only list of messages between participants. Every message goes to
 every participant.
 
+You can find threads you are not in: `pana thread search --query TEXT` searches the subject
+and messages of every same-domain thread, `pana thread list` lists them newest-created first
+with their `pana://` URLs, and `pana_thread_read` reads any thread or message by URL or ID.
```
## @joshbeckman [commented on Monday (2026-11-09) at 00:20:44](https://github.com/joshbeckman/dotfiles/pull/272#discussion_r4508431196)

I think we can tighten this up a bit, right? Like we don't have to tell them how it will output. They can use --help, too

## @joshbeckman reviewed (COMMENTED) on Monday (2026-11-09) at 00:21:08


## @ committed a change on Monday (2026-11-09) at 00:23:33

docs(pana): address the guide at a participant, and say less about ou…

…tput

Two review points:
- The ask belongs to a thread participant, not the user: a session can
  reply in a thread it shares with one, or start a thread with one
  (pana thread create --to). No participant is a moderator.
- Drop the search output shape from the prompt: pana thread search and
  pana thread list find threads, pana_thread_read reads any of them, and
  --help carries the detail.

PRM-09 says the same and its test now pins both points.

## @joshbeckman [commented on Monday (2026-11-09) at 00:23:41](https://github.com/joshbeckman/dotfiles/pull/272#issuecomment-6729296056)

Co-authored-by: AI pana://beacon.joshbeckman.org/threads/01M6MD5XX2TBGA9ZFHE9QMSDGY

> Both points taken, in `2f76fe6`.
>
> **On the addressee:** you're right, and the second clause was the tell — "a thread of your own addressed to the user" made the user the gatekeeper, which no rule says. It now reads "ask a participant: reply in a thread you share with one, or start a thread with one (`pana thread create --to ADDRS`)" — a session can open its own request thread with any participant, and the README says outright that no one is the moderator: any participant may add. `PRM-09` carries the same correction.
>
> **On the output shape:** dropped. The discovery paragraph is now one sentence naming the three commands and what they are for; the ordering and URL detail live in `--help` and the README. `PRM-09`'s test asserts the prompt no longer spells the output out.
>
> `npx tsc --noEmit` clean, `npm test` 687 passed / 2 skipped.


## @ committed a change on Monday (2026-11-09) at 00:30:06

docs(pana): use the CLI spelling throughout the thread-discovery sent…

…ence

pana_thread_read is a tool name; pana thread search and pana thread list
are commands. Mixing the two in one sentence reads as a third thing. The
paragraph now spells all three as commands and the tool list below it
keeps the tool-to-CLI mapping.

### ✅ @joshbeckman merged this on Monday (2026-11-09) at 00:38:51

### 🔒 @joshbeckman closed this on Monday (2026-11-09) at 00:38:51

### 🗑️ @joshbeckman deleted the head branch on Monday (2026-11-09) at 00:39:40



## Merged on Monday (2026-11-09) at 00:38:51
