# Issue #287: [Research: codemode token use and turn latency in Pana](https://github.com/joshbeckman/dotfiles/issues/287) opened by @joshbeckman on Wednesday (2026-11-11) at 14:40:15

## Finding

A small pilot found that codemode can run Pana tools through pi-durable, but did not show a consistent reduction in total tokens. Some configurations finished faster. Cost sometimes fell despite higher token counts because cached input was billed at a lower rate. These results are not enough to enable codemode by default.

## Question and hypothesis

Can model-written scripts that combine Pana tool calls reduce model tokens or turn completion time, compared with Pana's current direct tools? The proposed mechanism is to call several tools in one script, filter their responses there, and return only the useful data to the model.

## Method

We ran an isolated Pana daemon with an experimental pi-durable codemode extension. Normal Pana sessions were unchanged. We used pi-durable 1.4.0, pi-codemode 1.4.0, Node 24.22.1, one proxy-served model, and medium thinking. All measured responses in the thread experiment reported the same model. The model and provider are not named in this public summary, so this is not yet a fully reproducible public benchmark.

Each comparison used three sequential pairs of fresh conversations, with alternating order. Results below are medians. We timed input submission to conversation settlement with a monotonic clock; this is not thread-delivery or UI latency. Token totals are provider-reported totals including cached input and output. The reported reasoning count is already included in output. We scored exact JSON answers and kept failures in the results.

Two synthetic tasks were used:

1. **Files:** Find the three matching deployments in 48 JSON files.
2. **Threads:** Read 12 actual threads in the temporary Pana domain and find services blocked by security in the latest update. Each thread had an initial status, an intermediate message, and a final status. Some statuses changed.

## Results

| Task and tool policy | Baseline median time | Codemode median time | Baseline median total tokens | Codemode median total tokens | Exact answers (baseline / codemode) |
|---|---:|---:|---:|---:|---:|
| Files: `read` only vs codemode with nested `read` | 22.2 s | 12.4 s | 22,646 | 37,201 | 3/3 / 3/3 |
| Files: normal tools vs normal tools plus optional codemode | 11.7 s | 11.0 s | 23,086 | 32,524 | 2/3 / 3/3 |
| Threads: `pana_thread_read` only vs codemode with nested thread read | 10.2 s | 13.5 s | 22,889 | 45,224 | 3/3 / 3/3 |
| Threads: normal tools vs normal tools plus optional codemode | 14.6 s | 13.5 s | 45,183 | 51,773 | 3/3 / 3/3 |
| Threads: normal tools vs codemode as the only directly offered tool | 14.6 s | 10.8 s | 30,706 | 41,821 | 3/3 / 3/3 |

In the last row, codemode scripts could still call Pana tools and `bash`. The median reported cost was approximately $0.025 baseline and $0.022 with codemode. That difference reflects the provider's cache pricing as well as token use; it is not evidence of a general cost saving. In the file experiment's one non-exact baseline answer, the matching records were correct but the response included prose despite the JSON-only instruction.

In the file optional-codemode test, all three experimental runs chose `bash`, not codemode. In the thread optional-codemode test, the experimental runs did invoke codemode. The model often returned complete thread responses first, then made additional calls after output was truncated. Direct baseline runs could issue the 12 thread reads together.

## Prompt and measurement limits

- The Pana system prompt permits either Pana tools or their CLI equivalents. It does not generally instruct the model to prefer `bash`. It does ask sessions to use Git to inspect domain guidance. The read-only policy hid `bash`; one traced codemode run searched for `bash` before starting the task. The codemode-only policy corrected that by allowing nested `bash`.
- `pana_thread_read` currently declares its structured result's `body` as `unknown` to scripts. Codemode runs made discovery and shape-inspection calls. We separately tested an instruction to filter results inside the script and another that also described the result shape. Neither improved completion time in the read-only pilot. These prompt interventions are not the default setup and should not be pooled with it.
- The isolated daemon did not load a machine's default profile or a native MCP gateway. A profile that directs an external gateway through a CLI in `bash` is therefore outside this experiment.
- Three pairs, one model, synthetic data, cache variation, provider load, and different numbers of model requests limit the conclusions. One file pair used a routed model alias, though its reported served model matched the other pairs. The file and thread cases are separate experiments, not a pooled sample.
- We did not establish restart behavior, side-effect safety, or guard enforcement for a production codemode integration.

## Next experiments

- Test realistic multi-call workloads with a native gateway available to codemode, and compare against the existing CLI path. Preserve tool authorization and caller identity.
- Test better structured output declarations for Pana tools without assuming they improve performance. Measure discovery calls, truncation, token categories, cost, correctness, and latency.
- Validate nested worktree and timeout guards, interruption and replay behavior, and side-effect handling before any production rollout.
- Repeat with more paired runs, fixed provider/model versions, and separate cold- and warm-cache reporting. Record failures and per-pair results.

## Reproduction status

The prototype and its tests are currently in a local-only experimental worktree, not in the repository's published default branch. They create the fixtures, run the comparisons, and emit per-trial JSONL with tool calls, results, usage, and timing. Publishing or otherwise preserving that prototype is needed for independent reproduction; this issue does not imply it has been merged.

Co-authored-by: AI pana://josh-beckman.shopify.com/threads/01M738FFAV1XCP5D0GWBQD4RRE


